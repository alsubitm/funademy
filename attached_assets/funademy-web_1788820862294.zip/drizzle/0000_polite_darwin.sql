CREATE TABLE IF NOT EXISTS "bookings" (
	"id" serial PRIMARY KEY NOT NULL,
	"parent_name" text NOT NULL,
	"phone" varchar(32) NOT NULL,
	"child_age" integer NOT NULL,
	"program_slug" varchar(64) NOT NULL,
	"preferred_time" text DEFAULT '' NOT NULL,
	"city" text DEFAULT 'الرياض' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"locale" varchar(2) DEFAULT 'ar' NOT NULL,
	"source" text DEFAULT 'site' NOT NULL,
	"status" varchar(16) DEFAULT 'new' NOT NULL,
	"admin_note" text DEFAULT '' NOT NULL,
	"ip_hash" varchar(64) DEFAULT '' NOT NULL,
	"user_agent" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "events" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(64) NOT NULL,
	"page" text DEFAULT '' NOT NULL,
	"program_slug" varchar(64),
	"locale" varchar(2) DEFAULT 'ar' NOT NULL,
	"meta" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "faqs" (
	"id" serial PRIMARY KEY NOT NULL,
	"q_ar" text NOT NULL,
	"q_en" text NOT NULL,
	"a_ar" text NOT NULL,
	"a_en" text NOT NULL,
	"page" varchar(64) DEFAULT 'home' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "programs" (
	"id" serial PRIMARY KEY NOT NULL,
	"slug" varchar(64) NOT NULL,
	"name" text NOT NULL,
	"track" varchar(16) NOT NULL,
	"field_ar" text NOT NULL,
	"field_en" text NOT NULL,
	"age_min" integer NOT NULL,
	"age_max" integer NOT NULL,
	"session_min" integer NOT NULL,
	"class_cap" integer NOT NULL,
	"format_ar" text NOT NULL,
	"format_en" text NOT NULL,
	"one_liner_ar" text NOT NULL,
	"one_liner_en" text NOT NULL,
	"description_ar" text DEFAULT '' NOT NULL,
	"description_en" text DEFAULT '' NOT NULL,
	"builds" jsonb DEFAULT '{"ar":[],"en":[]}'::jsonb NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	CONSTRAINT "programs_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "settings" (
	"key" varchar(64) PRIMARY KEY NOT NULL,
	"value" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "slots" (
	"id" serial PRIMARY KEY NOT NULL,
	"program_slug" varchar(64) NOT NULL,
	"weekday" integer NOT NULL,
	"time" varchar(5) NOT NULL,
	"capacity" integer DEFAULT 12 NOT NULL,
	"seats_left" integer DEFAULT 12 NOT NULL,
	"format_ar" text DEFAULT 'أونلاين مباشر' NOT NULL,
	"format_en" text DEFAULT 'live online' NOT NULL,
	"is_open" boolean DEFAULT true NOT NULL,
	"starts_on" text
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "testimonials" (
	"id" serial PRIMARY KEY NOT NULL,
	"quote_ar" text NOT NULL,
	"quote_en" text NOT NULL,
	"who_ar" text NOT NULL,
	"who_en" text NOT NULL,
	"approved" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL
);
