import 'dotenv/config';
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import { programs, slots, faqs, testimonials, settings } from '../src/db/schema';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

const ENG = [
  { slug: 'big-builders', stem: 'S,E', name: 'Big Builders', fieldAr: 'العالم من حولنا', fieldEn: 'The world around us', ageMin: 4, ageMax: 6, sessionMin: 45, classCap: 12, formatAr: 'حضوري · الرياض', formatEn: 'in person · Riyadh',
    oneLinerAr: 'يبني الصغار العالم من حولهم — أول مفاهيم العلوم بالمكعّبات والقصص', oneLinerEn: 'Little builders build the world around them — first science concepts with bricks and stories',
    descriptionAr: 'في كل حصة قصة وسؤال ونموذج يُبنى بالأيدي الصغيرة: كيف تدور الطاحونة؟ لماذا يتوازن الأرجوحة؟ يتعلم الطفل الملاحظة والتوقع والتجربة قبل أن يعرف أنه يتعلم العلوم.',
    descriptionEn: 'Every session has a story, a question and a model built with small hands: how does the windmill turn? Why does the seesaw balance? The child learns to observe, predict and test before knowing it is science.',
    builds: { ar: ['طاحونة هواء', 'أرجوحة توازن', 'جسر متحرك', 'سيارة تتدحرج', 'رافعة صغيرة'], en: ['A windmill', 'A balancing seesaw', 'A drawbridge', 'A rolling car', 'A small crane'] } },
  { slug: 'smartivo', stem: 'T', name: 'Smartivo', fieldAr: 'البرمجة والروبوتات', fieldEn: 'Coding & robotics', ageMin: 4, ageMax: 6, sessionMin: 45, classCap: 12, formatAr: 'حضوري · الرياض', formatEn: 'in person · Riyadh',
    oneLinerAr: 'جميع أساسيات البرمجة للصغار — ملموسة أو على الشاشة', oneLinerEn: 'All the coding basics for little ones — tangible or on screen',
    descriptionAr: 'حضوريًا في الرياض: التسلسل والتكرار والشروط بلغة الصغار — أوامر تُرتَّب بالأيدي أو على الشاشة، وشخصية تتحرك عندما يكون الترتيب صحيحًا.',
    descriptionEn: 'In person in Riyadh: sequence, loops and conditions in a small child\'s language — commands arranged by hand or on screen, and a character that moves when the order is right.',
    builds: { ar: ['مسار لشخصية تتحرك', 'أغنية بأوامر متكررة', 'لعبة "إذا … فـ"', 'خريطة كنز مبرمجة'], en: ['A path for a moving character', 'A song made of repeated commands', 'An "if … then" game', 'A programmed treasure map'] } },
  { slug: 'bricks-challenge', stem: 'E,S', name: 'Bricks Challenge', fieldAr: 'الهندسة الميكانيكية', fieldEn: 'Mechanical engineering', ageMin: 6, ageMax: 10, sessionMin: 75, classCap: 16, formatAr: 'حضوري · الرياض', formatEn: 'in person · Riyadh',
    oneLinerAr: 'أساسيات الميكانيكا الكلاسيكية: تروس وروافع ونماذج تتحرك بمحركات حقيقية', oneLinerEn: 'Classical mechanics basics: gears, levers and models that move with real motors',
    descriptionAr: 'كل حصة نموذج يعمل بمحرك: تروس تنقل الحركة، وروافع ترفع الأثقال، وبكرات وكامات وأعمدة مرفقية. يبني الطفل ويشغّل ويشرح لماذا يعمل.',
    descriptionEn: 'Every session a motorised model: gears that transmit motion, levers that lift loads, pulleys, cams and crankshafts. The child builds, runs it and explains why it works.',
    builds: { ar: ['طاحونة بمحرك', 'دولاب ضخم', 'رافعة شوكية', 'خلاط تروس', 'مصعد ببكرة'], en: ['A motorised windmill', 'A ferris wheel', 'A forklift', 'A gear mixer', 'A pulley lift'] } },
  { slug: 'algoplay', stem: 'T,E', name: 'AlgoPlay', fieldAr: 'البرمجة والروبوتات', fieldEn: 'Coding & robotics', ageMin: 6, ageMax: 10, sessionMin: 75, classCap: 16, formatAr: 'حضوري · الرياض', formatEn: 'in person · Riyadh',
    oneLinerAr: 'أساسيات الروبوتات: تركيب وبرمجة على الشاشة', oneLinerEn: 'Robotics basics: building and coding on screen',
    descriptionAr: 'في قاعة FunAdemy في الرياض: روبوت يُركَّب ويُبرمج على الشاشة — حساسات وأوامر وحلقات، ومهمة يجب أن يكملها بنفسه. يتعلم الطفل التفكير الخوارزمي عمليًا.',
    descriptionEn: 'In the FunAdemy classroom in Riyadh: a robot assembled and coded on screen — sensors, commands and loops, and a mission it must complete on its own. The child learns algorithmic thinking by doing.',
    builds: { ar: ['روبوت يتبع خطًا', 'ذراع تلتقط الأشياء', 'حارس بحساس مسافة', 'سباق روبوتات مبرمج'], en: ['A line-following robot', 'An arm that picks things up', 'A guard with a distance sensor', 'A programmed robot race'] } },
  { slug: 'galileo-technic', stem: 'E,M', name: 'Galileo Technic', fieldAr: 'الهندسة الميكانيكية', fieldEn: 'Mechanical engineering', ageMin: 7, ageMax: 10, sessionMin: 75, classCap: 16, formatAr: 'حضوري · الرياض', formatEn: 'in person · Riyadh',
    oneLinerAr: 'الميكانيكا المتقدمة لبنّائين جاهزين للتحدي الأكبر', oneLinerEn: 'Advanced mechanics for builders ready for the bigger challenge',
    descriptionAr: 'نماذج أكبر وأدق: نقل حركة متعدد المراحل، توازن وقوى وعزوم، وتحديات تصميم يحلّها الطفل بطريقته ثم يقيس النتيجة.',
    descriptionEn: 'Bigger, finer models: multi-stage motion transfer, balance, forces and torque, and design challenges the child solves their own way, then measures.',
    builds: { ar: ['رافعة برجية', 'علبة تروس متعددة', 'آلة رمي', 'مضخة يدوية', 'ساعة ميكانيكية'], en: ['A tower crane', 'A multi-gear gearbox', 'A throwing machine', 'A hand pump', 'A mechanical clock'] } },
  { slug: 'robotoys', stem: 'T,E', name: 'RoboToys', fieldAr: 'البرمجة والروبوتات', fieldEn: 'Coding & robotics', ageMin: 9, ageMax: 12, sessionMin: 90, classCap: 16, formatAr: 'حضوري · الرياض', formatEn: 'in person · Riyadh',
    oneLinerAr: 'الروبوتات المتقدمة — مشاريع أعمق ومنطق أذكى', oneLinerEn: 'Advanced robotics — deeper projects, smarter logic',
    descriptionAr: 'حضوريًا في الرياض: روبوتات بمهام حقيقية — قراءة أكثر من حساس، اتخاذ قرار، متغيرات ودوال. كل شهر مشروع يُعرض ويُقيَّم.',
    descriptionEn: 'In person in Riyadh: robots with real jobs — reading more than one sensor, making decisions, variables and functions. Every month a project presented and reviewed.',
    builds: { ar: ['روبوت إنقاذ بمتاهة', 'سيارة ذاتية التوقف', 'مصنع فرز بالألوان', 'حارس ليلي بحساسات'], en: ['A maze rescue robot', 'A self-stopping car', 'A colour-sorting factory', 'A night guard with sensors'] } },
  { slug: 'algoc', stem: 'T,M', name: 'AlgoC', fieldAr: 'البرمجة والروبوتات', fieldEn: 'Coding & robotics', ageMin: 13, ageMax: 18, sessionMin: 90, classCap: 8, formatAr: 'حضوري · الرياض', formatEn: 'in person · Riyadh',
    oneLinerAr: 'هندسة البرمجة والروبوتات للمراهقين — الطريق إلى التطوير الحقيقي', oneLinerEn: 'Coding and robotics engineering for teens — the road to real development',
    descriptionAr: 'حضوريًا في الرياض: برمجة نصية حقيقية للروبوتات — دوال ومنطق ومعالجة حساسات، في مجموعات لا تتجاوز ثمانية. مشروع تخرج يُدافع عنه الطالب.',
    descriptionEn: 'In person in Riyadh: real text-based robot programming — functions, logic and sensor handling, in groups of no more than eight. A graduation project the student defends.',
    builds: { ar: ['روبوت يقرأ الحساسات ويقرر', 'محطة طقس مبرمجة', 'ذراع بأربع محاور', 'مشروع تخرج من اختيار الطالب'], en: ['A robot that reads sensors and decides', 'A programmed weather station', 'A four-axis arm', 'A graduation project of the student\'s choice'] } },
];

const SKY = [
  { slug: 'skylab-ground-crew', stem: 'S,M', name: 'SkyLab Ground Crew', ageMin: 4, ageMax: 6, sessionMin: 35, classCap: 8, oneLinerAr: 'فريق الأرض — مع ولي الأمر: أشكال وعدّ وحيوانات وماء وحرارة، بالأيدي قبل الأرقام', oneLinerEn: 'Ground Crew — parent beside: shapes, counting, animals, water and heat; hands before numbers',
    descriptionAr: 'حصص 35 دقيقة مع ولي الأمر بجانب الطفل: كل شهر مهمة صغيرة — طيارتي والأعداد، يغرق أم يطفو، عدّ القمر — وتجربة من حقيبة البيت.', descriptionEn: '35-minute sessions with a parent beside the child: a small mission every month — My Number Kite, Sink or Float, Moon Counting — and an experiment from the home box.',
    builds: { ar: ['طيارتي والأعداد', 'يغرق أم يطفو', 'أنماط النخيل', 'حار وبارد', 'عدّ القمر'], en: ['My Number Kite', 'Sink or Float', 'Pattern Palms', 'Hot & Cold', 'Moon Counting'] } },
  { slug: 'skylab-lift-off', stem: 'S,M', name: 'SkyLab Lift-Off', ageMin: 7, ageMax: 9, sessionMin: 45, classCap: 10, oneLinerAr: 'الإقلاع — العمليات الأربع والكسور والقياس؛ المادة والقوى والطقس والمغناطيس', oneLinerEn: 'Lift-Off — the four operations, fractions and measurement; matter, forces, weather and magnets',
    descriptionAr: 'أول أدوات حقيقية: إبريق قياس وميزان زنبركي وميزان حرارة. مهمات مثل قافلة الإبل وساعة الظل ومحطة أرصاد الرياض — وتنتهي السنة بمعرض علوم صغير.', descriptionEn: 'First real instruments: a measuring jug, a spring scale, a thermometer. Missions like Camel Caravan, Shadow Clock and Weather Station Riyadh — the year ends with a mini science fair.',
    builds: { ar: ['قافلة الإبل', 'ساعة الظل', 'محققو الماء', 'أرقام الصوت', 'محطة أرصاد الرياض'], en: ['Camel Caravan', 'Shadow Clock', 'Water Detectives', 'Sound Numbers', 'Weather Station Riyadh'] } },
  { slug: 'skylab-glide', stem: 'S,M', name: 'SkyLab Glide', ageMin: 10, ageMax: 12, sessionMin: 60, classCap: 12, oneLinerAr: 'الانسياب — النسب والكثافة والزوايا والبيانات؛ الطاقة والكيمياء ودورة الماء', oneLinerEn: 'Glide — ratios, density, angles and data; energy, chemistry and the water cycle',
    descriptionAr: 'صندوق يشبه المختبر: ميزان 0.1 غ ومخبار مدرج وشرائط pH وخلية شمسية. مهمات مثل مزرعة شمسية وغذاء الصقر ومطبخ الكيمياء — وتنتهي بمعرض تحقيق.', descriptionEn: 'A box that looks like a lab: a 0.1 g scale, a graduated cylinder, pH strips and a solar cell. Missions like Solar Farm, The Falcon\'s Diet and Chemistry Kitchen — ending with an investigation expo.',
    builds: { ar: ['مزرعة شمسية', 'غذاء الصقر', 'محققو الكثافة', 'زوايا السماء', 'مطبخ الكيمياء'], en: ['Solar Farm', 'The Falcon\'s Diet', 'Density Detectives', 'Angles of the Sky', 'Chemistry Kitchen'] } },
  { slug: 'skylab-soar', stem: 'M,S', name: 'SkyLab Soar', ageMin: 13, ageMax: 15, sessionMin: 75, classCap: 12, oneLinerAr: 'التحليق — الجبر والدوال والإحصاء؛ الخلايا والعناصر والموجات والوراثة', oneLinerEn: 'Soar — algebra, functions and statistics; cells, elements, waves and genetics',
    descriptionAr: 'الجبر يحتاج قياسًا يصدّقه: ساعة إيقاف وقدمة ومسطرة فولاذية. مهمات مثل جبر الطيران وهندسة القبة ومملكة البيانات — وتنتهي بملصق بحثي.', descriptionEn: 'Algebra needs measurement it can believe: a stopwatch, calipers and a steel ruler. Missions like Algebra of Flight, Geometry of the Dome and Data Kingdom — ending with a research poster.',
    builds: { ar: ['جبر الطيران', 'مدينة الخلية', 'هندسة القبة', 'مملكة البيانات', 'الموجات والدوال'], en: ['Algebra of Flight', 'Cell City', 'Geometry of the Dome', 'Data Kingdom', 'Waves & Functions'] } },
  { slug: 'skylab-orbit', stem: 'M,S', name: 'SkyLab Orbit', ageMin: 16, ageMax: 18, sessionMin: 90, classCap: 10, oneLinerAr: 'المدار — التفاضل والنمذجة وعلم البيانات؛ الدوائر والكيمياء الكمية ومشروع بحثي يُناقَش أمام لجنة', oneLinerEn: 'Orbit — calculus, modelling and data science; circuits, quantitative chemistry and a research project defended before a panel',
    descriptionAr: 'حقيبة بحث بملتيمتر وزجاجيات وميزان دقيق. مهمات مثل تفاضل التغير وميكانيكا الفضاء وتحوّل الطاقة — وتنتهي بمشروع المدار: ورقة بحثية ومناقشة أمام لجنة.', descriptionEn: 'A research case with a multimeter, glassware and a precision scale. Missions like Calculus of Change, Space Mechanics and Energy Transition — ending with the Orbit Capstone: a paper defended before a panel.',
    builds: { ar: ['تفاضل التغير', 'المجالات والدوائر', 'نمذجة أنظمة الجسم', 'ميكانيكا الفضاء', 'مشروع المدار'], en: ['Calculus of Change', 'Fields & Circuits', 'Body Systems Model', 'Space Mechanics', 'Orbit Capstone'] } },
];

const IP = ['حضوري · الرياض', 'in person · Riyadh'] as const;
const SLOTS = [
  ['smartivo', 0, '17:00', 12, 3, ...IP], ['algoplay', 1, '18:00', 16, 5, ...IP], ['robotoys', 2, '19:30', 16, 2, ...IP], ['skylab-lift-off', 3, '17:00', 10, 4], ['skylab-glide', 4, '18:30', 12, 3],
  ['bricks-challenge', 6, '10:00', 16, 6, ...IP], ['galileo-technic', 6, '11:30', 16, 2, ...IP], ['algoc', 0, '20:00', 8, 1, ...IP],
  ['big-builders', 6, '09:00', 12, 4, ...IP], ['algoplay', 3, '19:30', 16, 7, ...IP], ['robotoys', 0, '18:00', 16, 5, ...IP], ['skylab-lift-off', 1, '17:00', 10, 6], ['skylab-glide', 2, '18:30', 12, 5], ['smartivo', 2, '17:00', 12, 4, ...IP],
] as const;

const FAQS = [
  ['هل الحصص أونلاين أم حضورية؟', 'Are classes online or in person?', 'برامج الهندسة والبرمجة والروبوتات كلها حضورية في قاعة FunAdemy في الرياض. برنامج SkyLab للرياضيات والعلوم مباشر أونلاين لأي مكان.', 'All engineering, coding and robotics programs are in person in the FunAdemy classroom in Riyadh. SkyLab, the math and science program, is live online from anywhere.'],
  ['ما الذي أحتاجه في البيت؟', 'What do we need at home?', 'جهاز بكاميرا وإنترنت مستقر، وطاولة فاضية. حقيبة SkyLab تصل قبل الحصة الأولى.', 'A device with a camera, stable internet and a clear table. The SkyLab kit arrives before the first class.'],
  ['هل توجد شهادات؟', 'Are there certificates?', 'نعم — شهادة رسمية عند إتمام كل مستوى، وشارات شهرية في SkyLab.', 'Yes — an official certificate at the end of each level, and monthly badges in SkyLab.'],
  ['كم عدد الطلاب في المجموعة؟', 'How many students in a group?', 'من 8 إلى 16 حسب العمر — المراهقون في مجموعات لا تتجاوز 8.', '8 to 16 by age — teenagers in groups of no more than 8.'],
  ['هل يمكن الانضمام في منتصف السنة؟', 'Can we join mid-year?', 'نعم. في SkyLab كل مهمة شهرية مستقلة، وفي برامج الهندسة نضع الطفل في المجموعة المناسبة لمستواه.', 'Yes. Each SkyLab mission is self-contained, and in the engineering programs we place the child in the right group for their level.'],
  ['كيف أدفع؟', 'How do I pay?', 'مدى وبطاقات الائتمان وSTC Pay وتقسيط تمارا — بفاتورة إلكترونية معتمدة.', 'Mada, cards, STC Pay and Tamara instalments — with a compliant e-invoice.'],
];

// Placeholders: NOT approved — the site only shows approved (real, consented) testimonials.
const TESTIMONIALS = [
  ['«أول مرة أشوف ولدي يشرح لي التروس بدل ما أشرح له. الحصة التجريبية كانت كافية نقرر.»', '"The first time my son explained gears to me instead of the other way round. The trial class was enough to decide."', 'أم فيصل — الرياض', "Faisal's mother — Riyadh"],
  ['«يوم الإطلاق صار موعد العائلة الشهري. بنتي تجهز عرضها بنفسها.»', '"Launch Day has become our monthly family date. My daughter prepares her presentation herself."', 'أبو لينا — الرياض', "Lina's father — Riyadh"],
  ['«الحقيبة وصلت قبل الحصة، والتجربة صارت على طاولة المطبخ. وقت شاشة يبني مهارة.»', '"The kit arrived before the class, and the experiment happened on our kitchen table. Screen time that builds a skill."', 'أم يزن — الرياض', "Yazan's mother — Riyadh"],
];

async function main() {
  await db.delete(slots); await db.delete(faqs); await db.delete(testimonials); await db.delete(programs); await db.delete(settings);
  let i = 0;
  for (const p of ENG) await db.insert(programs).values({ ...p, track: 'engineering', sortOrder: i++ });
  for (const p of SKY) await db.insert(programs).values({ ...p, track: 'skylab', fieldAr: 'الرياضيات والعلوم', fieldEn: 'Math & science', formatAr: 'أونلاين مباشر', formatEn: 'live online', sortOrder: i++ });
  for (const s of SLOTS) await db.insert(slots).values({ programSlug: s[0], weekday: s[1], time: s[2], capacity: s[3], seatsLeft: s[4], formatAr: (s as readonly unknown[])[5] as string || 'أونلاين مباشر', formatEn: (s as readonly unknown[])[6] as string || 'live online' });
  for (const [j, f] of FAQS.entries()) await db.insert(faqs).values({ qAr: f[0], qEn: f[1], aAr: f[2], aEn: f[3], page: 'home', sortOrder: j });
  for (const [j, t] of TESTIMONIALS.entries()) await db.insert(testimonials).values({ quoteAr: t[0], quoteEn: t[1], whoAr: t[2], whoEn: t[3], approved: false, sortOrder: j });
  await db.insert(settings).values([{ key: 'brick_counter', value: '1847' }, { key: 'pilot_start', value: '2026-10-04' }]);
  await pool.end();
  console.log('seeded: programs', ENG.length + SKY.length, 'slots', SLOTS.length, 'faqs', FAQS.length, 'testimonials (unapproved)', TESTIMONIALS.length);
}
main().catch(e => { console.error(e); process.exit(1); });
