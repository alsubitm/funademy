import { pgTable, serial, text, integer, boolean, timestamp, jsonb, varchar } from 'drizzle-orm/pg-core';

export const programs = pgTable('programs', {
  id: serial('id').primaryKey(),
  slug: varchar('slug', { length: 64 }).notNull().unique(),
  name: text('name').notNull(),
  track: varchar('track', { length: 16 }).notNull(), // 'engineering' | 'skylab'
  fieldAr: text('field_ar').notNull(),
  fieldEn: text('field_en').notNull(),
  ageMin: integer('age_min').notNull(),
  ageMax: integer('age_max').notNull(),
  sessionMin: integer('session_min').notNull(),
  classCap: integer('class_cap').notNull(),
  formatAr: text('format_ar').notNull(),
  formatEn: text('format_en').notNull(),
  oneLinerAr: text('one_liner_ar').notNull(),
  oneLinerEn: text('one_liner_en').notNull(),
  descriptionAr: text('description_ar').notNull().default(''),
  descriptionEn: text('description_en').notNull().default(''),
  builds: jsonb('builds').$type<{ ar: string[]; en: string[] }>().notNull().default({ ar: [], en: [] }),
  stem: varchar('stem', { length: 8 }).notNull().default(''), // pillars covered, e.g. 'T,E' — first letter is primary
  sortOrder: integer('sort_order').notNull().default(0),
  active: boolean('active').notNull().default(true),
});

export const slots = pgTable('slots', {
  id: serial('id').primaryKey(),
  programSlug: varchar('program_slug', { length: 64 }).notNull(),
  weekday: integer('weekday').notNull(), // 0 = Sunday … 6 = Saturday
  time: varchar('time', { length: 5 }).notNull(), // 'HH:MM'
  capacity: integer('capacity').notNull().default(12),
  seatsLeft: integer('seats_left').notNull().default(12),
  formatAr: text('format_ar').notNull().default('أونلاين مباشر'),
  formatEn: text('format_en').notNull().default('live online'),
  isOpen: boolean('is_open').notNull().default(true),
  startsOn: text('starts_on'), // ISO date of the next cohort start (optional)
});

export const bookings = pgTable('bookings', {
  id: serial('id').primaryKey(),
  parentName: text('parent_name').notNull(),
  phone: varchar('phone', { length: 32 }).notNull(),
  childAge: integer('child_age').notNull(),
  programSlug: varchar('program_slug', { length: 64 }).notNull(),
  preferredTime: text('preferred_time').notNull().default(''),
  city: text('city').notNull().default('الرياض'),
  notes: text('notes').notNull().default(''),
  locale: varchar('locale', { length: 2 }).notNull().default('ar'),
  source: text('source').notNull().default('site'),
  status: varchar('status', { length: 16 }).notNull().default('new'), // new | contacted | trial_booked | enrolled | closed
  adminNote: text('admin_note').notNull().default(''),
  ipHash: varchar('ip_hash', { length: 64 }).notNull().default(''),
  userAgent: text('user_agent').notNull().default(''),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const testimonials = pgTable('testimonials', {
  id: serial('id').primaryKey(),
  quoteAr: text('quote_ar').notNull(),
  quoteEn: text('quote_en').notNull(),
  whoAr: text('who_ar').notNull(),
  whoEn: text('who_en').notNull(),
  approved: boolean('approved').notNull().default(false), // only real, consented testimonials are approved
  sortOrder: integer('sort_order').notNull().default(0),
});

export const faqs = pgTable('faqs', {
  id: serial('id').primaryKey(),
  qAr: text('q_ar').notNull(),
  qEn: text('q_en').notNull(),
  aAr: text('a_ar').notNull(),
  aEn: text('a_en').notNull(),
  page: varchar('page', { length: 64 }).notNull().default('home'),
  sortOrder: integer('sort_order').notNull().default(0),
  active: boolean('active').notNull().default(true),
});

export const events = pgTable('events', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 64 }).notNull(),
  page: text('page').notNull().default(''),
  programSlug: varchar('program_slug', { length: 64 }),
  locale: varchar('locale', { length: 2 }).notNull().default('ar'),
  meta: jsonb('meta').$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const settings = pgTable('settings', {
  key: varchar('key', { length: 64 }).primaryKey(),
  value: text('value').notNull().default(''),
});

export type Program = typeof programs.$inferSelect;
export type Slot = typeof slots.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Testimonial = typeof testimonials.$inferSelect;
export type Faq = typeof faqs.$inferSelect;
