import { NextResponse } from 'next/server';
import { isAdmin } from './auth';
/** Guard for admin API routes: 401 unless the signed admin cookie is valid. */
export function requireAdmin() { return isAdmin() ? null : NextResponse.json({ error: 'Unauthorized' }, { status: 401 }); }
