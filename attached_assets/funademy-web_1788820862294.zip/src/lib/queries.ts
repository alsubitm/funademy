import { asc, eq, and } from 'drizzle-orm';
import { db, schema } from './db';
const { programs, slots, faqs, testimonials } = schema;

export const getPrograms = () => db.select().from(programs).where(eq(programs.active, true)).orderBy(asc(programs.sortOrder));
export const getProgram = async (slug: string) => (await db.select().from(programs).where(and(eq(programs.slug, slug), eq(programs.active, true))).limit(1))[0];
export const getOpenSlots = () => db.select().from(slots).where(eq(slots.isOpen, true)).orderBy(asc(slots.weekday), asc(slots.time));
export const getSlotsFor = (slug: string) => db.select().from(slots).where(and(eq(slots.isOpen, true), eq(slots.programSlug, slug))).orderBy(asc(slots.weekday), asc(slots.time));
export const getFaqs = (page = 'home') => db.select().from(faqs).where(and(eq(faqs.active, true), eq(faqs.page, page))).orderBy(asc(faqs.sortOrder));
export const getApprovedTestimonials = () => db.select().from(testimonials).where(eq(testimonials.approved, true)).orderBy(asc(testimonials.sortOrder));
export const getSetting = async (key: string) => (await db.select().from(schema.settings).where(eq(schema.settings.key, key)).limit(1))[0]?.value ?? null;
