export type Locale = 'ar' | 'en';
export const LOCALES: Locale[] = ['ar', 'en'];
export const isLocale = (x: string): x is Locale => x === 'ar' || x === 'en';
export const dir = (l: Locale) => (l === 'ar' ? 'rtl' : 'ltr');
/** Build an href for a path in the given locale. Arabic is the default at the root. */
export const href = (l: Locale, path: string) => (l === 'ar' ? (path === '' ? '/' : path) : `/en${path === '/' ? '' : path}` || '/en');
export const WA = () => `https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP || '966505558387'}`;
export const WEEKDAYS: Record<Locale, string[]> = {
  ar: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
  en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
};

const ar = {
  brand: 'FunAdemy', tagline: 'حيث تلتقي المتعة بالأكاديمية',
  nav: { programs: 'البرامج', skylab: 'SkyLab', pricing: 'الأسعار', campaign: 'الحملة الوطنية', schools: 'للمدارس', contact: 'تواصل', book: 'احجز حصة مجانية', lang: 'EN', menu: 'القائمة', skip: 'تخطَّ إلى المحتوى' },
  hero: {
    h1a: 'لا نعلّم أطفالنا عن الهندسة\u00a0—', h1b: 'بل نصنع منهم مهندسين.',
    whisper: 'هندسة وروبوتات وبرمجة حضوريًا في الرياض · رياضيات وعلوم مباشرة أونلاين · من أول مكعّب إلى أول سطر برمجة',
    cta: 'احجز الحصة التجريبية المجانية', wa: 'واتساب',
    chips: ['الأعمار 4–18', 'الهندسة والبرمجة حضوريًا في الرياض', 'SkyLab أونلاين للجميع', 'مجموعات صغيرة 8–16'],
    kite: 'الطيارة = المتعة', cap: 'القبعة = الأكاديمية',
  },
  ticker: { live: 'مباشر', seats: 'مقاعد', empty: 'المواعيد الجديدة تُعلن هنا' },
  rail: { h: 'كم عمر طفلك؟', p: 'اختر العمر وسنعرض لك مسارَي FunAdemy المناسبين: برنامج الهندسة، وارتفاع SkyLab للرياضيات والعلوم.', ages: 'الأعمار', min: 'دقيقة', upto: 'حتى', students: 'طالبًا', online: 'أونلاين مباشر', book: 'احجز هذا البرنامج' },
  tracks: {
    h: 'مساران، هدف واحد: مهندس صغير',
    eng: 'الهندسة والروبوتات', engP: 'سبعة برامج حضورية في الرياض، في ثلاثة مجالات من 4 إلى 18 سنة: ميكانيكا حقيقية بمحركات، وبرمجة وروبوتات في قاعة FunAdemy.', engCredit: 'المنهج الرسمي لبرنامج e² Young Engineers العالمي', engCta: 'تصفح البرامج',
    sky: 'SkyLab — الرياضيات والعلوم', skyP: 'برنامج FunAdemy الأصلي: مهمة سعودية واحدة كل شهر، أربع حصص مباشرة، وحقيبة تجارب منزلية — خمسة ارتفاعات من 4 إلى 18.', skyNote: 'لا درجات ولا امتحانات: سجل طيران وشارات ويوم إطلاق أمام الأهل كل شهر.', skyCta: 'اكتشف SkyLab',
  },
  how: { h: 'كيف تبدأ رحلة طفلك', steps: [['حصة تجريبية مجانية', 'احجز خلال دقيقة، ونتصل بك خلال 24 ساعة.'], ['نختار البرنامج معًا', 'حسب العمر والميول: هندسة، أو SkyLab، أو الاثنان.'], ['تصل الحقيبة إلى البيت', 'تجارب حقيقية تُجرى مباشرة أثناء الحصة.'], ['حصص أسبوعية مباشرة', 'معلم حقيقي، مجموعة صغيرة، وتقرير لك بعد كل حصة.'], ['يوم الإطلاق والشهادة', 'يعرض طفلك نتيجته أمامك — ويكسب شارته.']] },
  price: { h: 'سعر واحد بسيط', unit: 'ريال / طفل / برنامج شهريًا', free: 'الحصة الأولى مجانية', tryH: 'جرّب قبل أن تقرر', tryP: 'حصة تجريبية كاملة مع المعلم والمجموعة — بلا التزام.', tryCta: 'احجز الحصة المجانية',
    value: ['4–6 حصص مباشرة شهريًا حسب البرنامج', 'مدة الحصة حسب العمر: 45 / 75 / 90 دقيقة', 'مجموعات صغيرة: 8–16 طالبًا كحد أقصى', 'منهج رسمي وشهادات · تقرير للأهل بعد كل حصة', 'خصم 10٪ لكل طفل إضافي من العائلة'],
    incH: 'ماذا يشمل الاشتراك', inc: [['حصص مباشرة شهريًا', '4–6'], ['مدة الحصة حسب العمر', '45 / 75 / 90'], ['حجم المجموعة', '8–16'], ['تقرير للأهل بعد كل حصة', '✓'], ['شهادة عند إتمام المستوى', '✓'], ['حقيبة SkyLab المنزلية', 'مشمولة مع التزام 3 أشهر'], ['خصم الإخوة', '−10%']],
    payH: 'الدفع', payP: 'مدى · بطاقات الائتمان · STC Pay · تقسيط تمارا. فاتورة إلكترونية معتمدة مع كل دفعة. يمكن الإيقاف نهاية أي شهر.', exH: 'مثال لعائلة', exP: 'طفلان في برنامجين: 1,380 + 1,242 (بعد خصم 10٪) = 2,622 ريالًا شهريًا.', cta: 'ابدأ بالحصة المجانية' },
  campaign: { h: 'أطفالنا يبنون وطننا', p: 'حملة عام كامل بأربع مراحل تتبع الفصول الدراسية — من بيت الطفل إلى وطنه — وتنتهي في «وطن مصغر»: بطولة هندسية بين المدارس في اليوم الوطني 2027.', phases: ['بيتي', 'حيّي', 'مدينتي', 'وطننا'], terms: ['الفصل الأول', 'الفصل الثاني', 'الفصل الثالث', 'اليوم الوطني'], more: 'تفاصيل الحملة و«وطن مصغر»', mwH: 'وطن مصغر — 23 سبتمبر 2027', mwP: 'بطولة هندسية بين المدارس: فرق من طلاب FunAdemy والمدارس الشريكة تبني نموذجًا لمعلم وطني، وتعرضه أمام لجنة وجمهور في اليوم الوطني. الجائزة: المكعّب الذهبي.', mwCta: 'سجّل مدرستك', pageP: 'حملة FunAdemy الوطنية لعام كامل: في كل فصل دراسي يبني الأطفال ما حولهم بأيديهم وأرقامهم — بيتهم، ثم حيّهم، ثم مدينتهم، ثم وطنهم.' },
  testi: { h: 'ماذا يقول الأهالي' },
  faq: { h: 'أسئلة يسألها الأهالي' },
  programs: { h: 'برامج الهندسة والروبوتات', p: 'سبعة برامج في ثلاثة مجالات. مسار التعلم: Big Builders ← Smartivo ← Bricks Challenge ← AlgoPlay ← Galileo Technic ← RoboToys ← AlgoC.', credit: 'المنهج والشهادات: e² Young Engineers الرسمي. جميع برامج الهندسة والبرمجة حضورية في الرياض.', cta: 'احجز الحصة التجريبية المجانية', builds: 'ماذا يبني طفلك', session: 'شكل الحصة', sessionSteps: ['يبني', 'يختبر', 'يحسّن', 'يعرض'], slots: 'المواعيد المتاحة', also: 'لهذا العمر أيضًا', cert: 'شهادة المستوى: FunAdemy · curriculum by e² Young Engineers', bookThis: 'احجز هذا البرنامج', back: 'كل البرامج', level: 'المستوى' },
  skylab: {
    h: 'FunAdemy SkyLab — مختبر السماء', p: 'برنامج رياضيات وعلوم مباشر أونلاين من 4 إلى 18 سنة. كل شهر مهمة سعودية حقيقية: لماذا يطول الظل عصرًا؟ كم لترًا يفقد الحاج في الساعة؟ ما سرعة القمر الصناعي فوق المملكة؟ العلوم تُنتج البيانات، والرياضيات تفسّرها.',
    arcH: 'مهمة واحدة = شهر واحد = أربع حصص', arc: ['التساؤل', 'التحقيق', 'الرياضيات', 'يوم الإطلاق'], altH: 'خمسة ارتفاعات', th: ['المستوى', 'الأعمار', 'الحصة', 'ما الذي يتعلمه'], parent: 'مع ولي الأمر',
    cards: [['حقيبة SkyLab المنزلية', 'أدوات قياس حقيقية وتجارب مطبخ آمنة تصل قبل الحصة الأولى — وتُستعمل مباشرة في الحصة.'], ['سجل الطيران والشارات', 'لا درجات. كل مهمة صفحة في سجل الطفل وشارة تُمنح في يوم الإطلاق؛ ثماني شارات = شهادة المستوى.'], ['بالعربية أولًا', 'كل مفهوم بالعربية أولًا ثم مصطلحه العلمي بالإنجليزية — ستة مصطلحات في كل مهمة.']],
    pilotH: 'الإطلاق التجريبي: أكتوبر 2026', pilotP: 'مجموعتا Lift-Off (7–9) وGlide (10–12) تبدآن في أكتوبر؛ جميع المستويات من يناير 2027. المقاعد محدودة.', pilotCta: 'احجز مقعد طفلك في المهمة الأولى',
  },
  book: { h: 'احجز الحصة التجريبية المجانية', p: 'نتصل بك خلال 24 ساعة لتأكيد الموعد. لا بطاقة ولا التزام.', name: 'اسم ولي الأمر', phone: 'رقم الجوال', age: 'عمر الطفل', program: 'البرنامج', time: 'الوقت المفضل', times: ['بعد المدرسة 16:00–18:00', 'مساءً 18:00–20:00', 'صباح السبت', 'صباح الجمعة'], city: 'المدينة', notes: 'ملاحظات (اختياري)', send: 'أرسل الطلب', wa: 'أو احجز عبر واتساب', privacy: 'بياناتك تُحفظ داخل المملكة ولا تُشارك مع أي طرف ثالث — نظام حماية البيانات الشخصية.', ok: 'تم استلام طلبك. سنتصل بك خلال 24 ساعة لتأكيد موعد الحصة المجانية.', err: 'تعذّر إرسال الطلب. تأكد من رقم الجوال ثم حاول مرة أخرى — أو احجز عبر واتساب.', sending: 'جارٍ الإرسال…', phoneHint: '05X XXX XXXX' },
  schools: { h: 'للمدارس والشركاء', p: 'نبدأ بيوم هندسي مجاني في مدرستكم — ثم نبني معًا: نادٍ بعد المدرسة، برنامج منهجي، معرض علوم، أو فريق لبطولة «وطن مصغر».', offers: [['يوم هندسي مجاني', 'ورشة لصف كامل بمعلمينا وأدواتنا — بلا تكلفة.'], ['نادٍ بعد المدرسة', 'حصص أسبوعية في مبنى المدرسة أو أونلاين.'], ['برنامج منهجي', 'هندسة أو SkyLab داخل الجدول الدراسي، بتقارير للمدرسة.'], ['المعارض والبطولة', 'معرض علوم للمدرسة، وفريق لبطولة «وطن مصغر».']], cta: 'اطلب عرضًا للمدرسة' },
  contact: { h: 'تواصل معنا', p: 'الهندسة والبرمجة حضوريًا في الرياض — وSkyLab أونلاين للجميع.', wa: 'واتساب', waP: 'الأسرع للحجز والأسئلة — نرد خلال ساعات العمل.', mail: 'البريد', mailP: 'للمدارس والشراكات والفواتير.', follow: 'تابعنا', followP: 'مقاطع من الحصص، ويوم الإطلاق، والحملة الوطنية.' },
  footer: { about: 'حيث تلتقي المتعة بالأكاديمية. أكاديمية STEM مرخّصة في الرياض — هندسة وبرمجة حضوريًا للأطفال من 4 إلى 18 سنة، وبرنامج SkyLab للرياضيات والعلوم أونلاين.', programs: 'البرامج', links: 'روابط', contact: 'تواصل', privacy: 'سياسة الخصوصية', terms: 'شروط الاشتراك', credit: 'FunAdemy · e² Young Engineers · Falcon Eye Ltd — License 4030388340', orig: 'SkyLab برنامج أصلي من FunAdemy. © 2026 Falcon Eye Ltd · الرياض · funademy.io' },
  legal: { privacyH: 'سياسة الخصوصية', termsH: 'شروط الاشتراك' },
  notfound: { h: 'هذه الصفحة لم تُقلع بعد', p: 'الرابط غير موجود. عد إلى الصفحة الرئيسية أو احجز حصة تجريبية مجانية.', home: 'الرئيسية' },
  mobile: { book: 'احجز حصة مجانية', wa: 'واتساب' },
};

const en: typeof ar = {
  brand: 'FunAdemy', tagline: 'Where fun meets academy',
  nav: { programs: 'Programs', skylab: 'SkyLab', pricing: 'Pricing', campaign: 'National campaign', schools: 'For schools', contact: 'Contact', book: 'Book a free class', lang: 'عربي', menu: 'Menu', skip: 'Skip to content' },
  hero: {
    h1a: "We don't teach kids about engineering\u00a0—", h1b: 'we make them engineers.',
    whisper: 'Engineering, robotics and coding in person in Riyadh · math and science live online · from the first brick to the first line of code',
    cta: 'Book the free trial class', wa: 'WhatsApp',
    chips: ['Ages 4–18', 'Engineering & coding in person in Riyadh', 'SkyLab live online for everyone', 'Small groups 8–16'],
    kite: 'kite = fun', cap: 'cap = academy',
  },
  ticker: { live: 'LIVE', seats: 'seats', empty: 'New class times are announced here' },
  rail: { h: 'How old is your child?', p: 'Pick an age and we show the two FunAdemy tracks that fit: the engineering program and the SkyLab altitude for math and science.', ages: 'Ages', min: 'min', upto: 'up to', students: 'students', online: 'live online', book: 'Book this program' },
  tracks: {
    h: 'Two tracks, one goal: a young engineer',
    eng: 'Engineering & robotics', engP: 'Seven in-person programs in Riyadh, in three fields for ages 4 to 18: real mechanics with motors, and coding and robotics in the FunAdemy classroom.', engCredit: 'Official e² Young Engineers curriculum', engCta: 'Browse programs',
    sky: 'SkyLab — math & science', skyP: "FunAdemy's original program: one Saudi mission a month, four live sessions and a home experiment kit — five altitudes from 4 to 18.", skyNote: 'No grades, no exams: a Flight Log, badges and a Launch Day in front of the family every month.', skyCta: 'Discover SkyLab',
  },
  how: { h: "How your child's journey starts", steps: [['Free trial class', 'Book in a minute; we call within 24 hours.'], ['We choose the program together', 'By age and interest: engineering, SkyLab, or both.'], ['The kit arrives at home', 'Real experiments run live during the session.'], ['Weekly live sessions', 'A real teacher, a small group and a report after every class.'], ['Launch Day and certificate', 'Your child presents to you — and earns the badge.']] },
  price: { h: 'One simple price', unit: 'SAR / child / program a month', free: 'The first class is free', tryH: 'Try before you decide', tryP: 'A full trial class with the teacher and the group — no commitment.', tryCta: 'Book the free class',
    value: ['4–6 live sessions a month by program', 'Session length by age: 45 / 75 / 90 minutes', 'Small groups: 8–16 students at most', 'Official curriculum and certificates · a parent report after every class', '10% off for every additional child in the family'],
    incH: 'What the subscription includes', inc: [['Live sessions a month', '4–6'], ['Session length by age', '45 / 75 / 90'], ['Group size', '8–16'], ['Parent report after every class', '✓'], ['Certificate at the end of the level', '✓'], ['Home SkyLab Kit', 'included with a 3-month commitment'], ['Sibling discount', '−10%']],
    payH: 'Payment', payP: 'Mada · credit cards · STC Pay · Tamara instalments. A compliant e-invoice with every payment. Pause at the end of any month.', exH: 'A family example', exP: 'Two children in two programs: 1,380 + 1,242 (after 10% off) = SAR 2,622 a month.', cta: 'Start with the free class' },
  campaign: { h: 'Our children build our nation', p: 'A year-long campaign in four school-term phases — from the child\'s home to the nation — ending in Mini Watan, an inter-school engineering championship on National Day 2027.', phases: ['My home', 'My neighbourhood', 'My city', 'Our nation'], terms: ['Term 1', 'Term 2', 'Term 3', 'National Day'], more: 'The campaign and Mini Watan', mwH: 'Mini Watan — 23 September 2027', mwP: 'An inter-school engineering championship: teams from FunAdemy and partner schools build a model of a national landmark and present it to a panel and an audience on National Day. The prize: the Golden Brick.', mwCta: 'Register your school', pageP: "FunAdemy's year-long national campaign: each school term, children build what surrounds them with their hands and their numbers — their home, then their neighbourhood, their city, and their nation." },
  testi: { h: 'What parents say' },
  faq: { h: 'Questions parents ask' },
  programs: { h: 'Engineering & robotics programs', p: 'Seven programs in three fields. Learning path: Big Builders → Smartivo → Bricks Challenge → AlgoPlay → Galileo Technic → RoboToys → AlgoC.', credit: 'Curriculum and certificates: official e² Young Engineers. All engineering and coding programs are in person in Riyadh.', cta: 'Book the free trial class', builds: 'What your child builds', session: 'A session', sessionSteps: ['build', 'test', 'improve', 'present'], slots: 'Available times', also: 'Also for this age', cert: 'Level certificate: FunAdemy · curriculum by e² Young Engineers', bookThis: 'Book this program', back: 'All programs', level: 'Level' },
  skylab: {
    h: 'FunAdemy SkyLab', p: 'A live online math and science program for ages 4 to 18. Every month a real Saudi mission: why is the shadow longest at Asr? How many litres does a pilgrim lose an hour? How fast is the satellite above the Kingdom? Science produces the data; math explains it.',
    arcH: 'One mission = one month = four sessions', arc: ['Wonder', 'Investigate', 'Do the math', 'Launch Day'], altH: 'Five altitudes', th: ['Level', 'Ages', 'Session', 'What they learn'], parent: 'parent beside',
    cards: [['The Home SkyLab Kit', 'Real measuring instruments and safe kitchen experiments delivered before the first class — and used live in the session.'], ['Flight Log and badges', "No grades. Every mission is a page in the child's log and a badge awarded on Launch Day; eight badges = the level certificate."], ['Arabic first', 'Every concept in Arabic first, then its scientific term in English — six terms in every mission.']],
    pilotH: 'Pilot: October 2026', pilotP: 'Lift-Off (7–9) and Glide (10–12) groups start in October; all levels from January 2027. Seats are limited.', pilotCta: "Reserve your child's seat in Mission 1",
  },
  book: { h: 'Book the free trial class', p: 'We call within 24 hours to confirm the time. No card, no commitment.', name: "Parent's name", phone: 'Mobile number', age: "Child's age", program: 'Program', time: 'Preferred time', times: ['After school 16:00–18:00', 'Evening 18:00–20:00', 'Saturday morning', 'Friday morning'], city: 'City', notes: 'Notes (optional)', send: 'Send the request', wa: 'Or book on WhatsApp', privacy: 'Your data is stored inside the Kingdom and never shared with third parties — Saudi PDPL.', ok: 'Request received. We will call within 24 hours to confirm the free class.', err: 'The request could not be sent. Check the mobile number and try again — or book on WhatsApp.', sending: 'Sending…', phoneHint: '05X XXX XXXX' },
  schools: { h: 'For schools and partners', p: 'We start with a free Engineering Day at your school — then build together: an after-school club, a curricular program, a science fair, or a team for Mini Watan.', offers: [['Free Engineering Day', 'A workshop for a whole class with our teachers and tools — at no cost.'], ['After-school club', 'Weekly sessions on campus or online.'], ['Curricular program', 'Engineering or SkyLab inside the timetable, with school reports.'], ['Fairs and the championship', 'A school science fair and a Mini Watan team.']], cta: 'Request a school proposal' },
  contact: { h: 'Contact us', p: 'Engineering and coding in person in Riyadh — SkyLab online for everyone.', wa: 'WhatsApp', waP: 'Fastest for booking and questions — we reply in working hours.', mail: 'Email', mailP: 'For schools, partnerships and invoices.', follow: 'Follow', followP: 'Clips from classes, Launch Days and the national campaign.' },
  footer: { about: 'Where fun meets academy. A licensed STEM academy in Riyadh — engineering and coding in person for ages 4 to 18, and the SkyLab math and science program online.', programs: 'Programs', links: 'Links', contact: 'Contact', privacy: 'Privacy policy', terms: 'Terms of enrolment', credit: 'FunAdemy · e² Young Engineers · Falcon Eye Ltd — License 4030388340', orig: 'SkyLab is an original FunAdemy program. © 2026 Falcon Eye Ltd · Riyadh · funademy.io' },
  legal: { privacyH: 'Privacy policy', termsH: 'Terms of enrolment' },
  notfound: { h: "This page hasn't launched", p: 'The link does not exist. Go back to the home page or book a free trial class.', home: 'Home' },
  mobile: { book: 'Book a free class', wa: 'WhatsApp' },
};

export const DICT: Record<Locale, typeof ar> = { ar, en };
export type Dict = typeof ar;
