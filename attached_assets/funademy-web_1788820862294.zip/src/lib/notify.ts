import nodemailer from 'nodemailer';
import type { Booking } from '@/db/schema';

export async function notifyBooking(b: Booking, programName: string) {
  const lines = [
    `New free-trial request #${b.id}`,
    `Parent: ${b.parentName}`, `Phone: ${b.phone}`, `Child age: ${b.childAge}`,
    `Program: ${programName} (${b.programSlug})`, `Preferred time: ${b.preferredTime}`,
    `City: ${b.city}`, `Notes: ${b.notes || '-'}`, `Locale: ${b.locale}`, `Created: ${b.createdAt.toISOString()}`,
  ];
  const text = lines.join('\n');
  // Email (optional)
  if (process.env.SMTP_HOST && process.env.NOTIFY_EMAIL) {
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: false,
        auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
      });
      await transporter.sendMail({ from: `FunAdemy <${process.env.SMTP_USER || 'noreply@funademy.io'}>`, to: process.env.NOTIFY_EMAIL, subject: `FunAdemy · trial request · ${b.parentName} · ${programName}`, text });
    } catch (e) { console.error('[notify] email failed', e); }
  } else {
    console.log('[notify] (no SMTP configured)\n' + text);
  }
  // WhatsApp Business webhook (optional): POST JSON to a relay of your choice
  if (process.env.WHATSAPP_WEBHOOK_URL) {
    try {
      await fetch(process.env.WHATSAPP_WEBHOOK_URL, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ type: 'booking', booking: b, programName, text }) });
    } catch (e) { console.error('[notify] whatsapp webhook failed', e); }
  }
}
