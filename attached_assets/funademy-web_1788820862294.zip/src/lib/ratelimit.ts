import { createHash } from 'crypto';
const hits = new Map<string, number[]>();
export function ipHash(ip: string) { return createHash('sha256').update(ip + (process.env.AUTH_SECRET || '')).digest('hex').slice(0, 32); }
/** Allow `limit` requests per `windowMs` per key (per server instance). */
export function allow(key: string, limit = 5, windowMs = 10 * 60 * 1000) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= limit) { hits.set(key, arr); return false; }
  arr.push(now); hits.set(key, arr); return true;
}
