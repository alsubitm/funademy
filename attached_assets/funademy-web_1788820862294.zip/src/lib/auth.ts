import { createHmac, timingSafeEqual } from 'crypto';
import { cookies } from 'next/headers';

const COOKIE = 'fa_admin';
const secret = () => process.env.AUTH_SECRET || 'dev-secret';

export function signToken(expiresAt: number) {
  const payload = `admin:${expiresAt}`;
  const sig = createHmac('sha256', secret()).update(payload).digest('hex');
  return `${expiresAt}.${sig}`;
}
export function verifyToken(token?: string | null) {
  if (!token) return false;
  const [exp, sig] = token.split('.');
  if (!exp || !sig) return false;
  if (Number(exp) < Date.now()) return false;
  const expected = createHmac('sha256', secret()).update(`admin:${exp}`).digest('hex');
  try { return timingSafeEqual(Buffer.from(sig), Buffer.from(expected)); } catch { return false; }
}
export function isAdmin() {
  return verifyToken(cookies().get(COOKIE)?.value);
}
export function adminCookie(token: string) {
  return { name: COOKIE, value: token, httpOnly: true, sameSite: 'lax' as const, secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 60 * 60 * 12 };
}
export const ADMIN_COOKIE = COOKIE;
