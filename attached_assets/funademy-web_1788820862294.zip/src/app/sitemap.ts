import type { MetadataRoute } from 'next';
export const dynamic = 'force-dynamic';
import { getPrograms } from '@/lib/queries';
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const site = process.env.SITE_URL || 'https://funademy.io';
  const paths = ['', '/programs', '/skylab', '/pricing', '/book', '/campaign', '/schools', '/contact', '/privacy', '/terms'];
  const progs = (await getPrograms().catch(() => [])).filter(p => p.track === 'engineering').map(p => `/programs/${p.slug}`);
  const all = [...paths, ...progs];
  return all.flatMap(p => [{ url: `${site}${p || '/'}`, alternates: { languages: { ar: `${site}${p || '/'}`, en: `${site}/en${p}` } } }, { url: `${site}/en${p}` }]);
}
