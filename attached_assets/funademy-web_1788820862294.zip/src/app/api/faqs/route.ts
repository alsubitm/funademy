import { NextResponse } from 'next/server';
import { getFaqs } from '@/lib/queries';
export const dynamic = 'force-dynamic';
export async function GET(req: Request) { const page = new URL(req.url).searchParams.get('page') || 'home'; return NextResponse.json(await getFaqs(page)); }
