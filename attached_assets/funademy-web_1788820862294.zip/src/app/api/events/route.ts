import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db, schema } from '@/lib/db';
import { allow, ipHash } from '@/lib/ratelimit';
const Ev = z.object({ name: z.string().min(1).max(64), page: z.string().max(200).default(''), locale: z.enum(['ar', 'en']).default('ar'), programSlug: z.string().max(64).optional(), meta: z.record(z.unknown()).default({}) });
export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'local';
  if (!allow('ev:' + ipHash(ip), 120, 60_000)) return NextResponse.json({ ok: false }, { status: 429 });
  const parsed = Ev.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ ok: false }, { status: 400 });
  const { name, page, locale, programSlug, meta } = parsed.data;
  await db.insert(schema.events).values({ name, page, locale, programSlug: programSlug ?? null, meta });
  return NextResponse.json({ ok: true });
}
