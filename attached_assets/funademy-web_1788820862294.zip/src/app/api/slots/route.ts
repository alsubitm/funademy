import { NextResponse } from 'next/server';
import { getOpenSlots } from '@/lib/queries';
export const dynamic = 'force-dynamic';
export async function GET() { return NextResponse.json(await getOpenSlots()); }
