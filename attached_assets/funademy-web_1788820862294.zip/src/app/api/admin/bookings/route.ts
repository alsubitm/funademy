import { NextResponse } from 'next/server';
import { desc } from 'drizzle-orm';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
export const dynamic = 'force-dynamic';
export async function GET(req: Request) {
  const g = requireAdmin(); if (g) return g;
  const rows = await db.select().from(schema.bookings).orderBy(desc(schema.bookings.createdAt)).limit(2000);
  if (new URL(req.url).searchParams.get('format') === 'csv') {
    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const head = ['id', 'created_at', 'status', 'parent_name', 'phone', 'child_age', 'program', 'preferred_time', 'city', 'notes', 'locale', 'admin_note'];
    const body = rows.map(r => [r.id, r.createdAt.toISOString(), r.status, r.parentName, r.phone, r.childAge, r.programSlug, r.preferredTime, r.city, r.notes, r.locale, r.adminNote].map(esc).join(','));
    return new NextResponse('\ufeff' + [head.join(','), ...body].join('\n'), { headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': 'attachment; filename="funademy-bookings.csv"' } });
  }
  return NextResponse.json(rows);
}
