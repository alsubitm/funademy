import { NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
const Patch = z.object({ status: z.enum(['new', 'contacted', 'trial_booked', 'enrolled', 'closed']).optional(), adminNote: z.string().max(600).optional() });
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const g = requireAdmin(); if (g) return g;
  const p = Patch.safeParse(await req.json().catch(() => null)); if (!p.success) return NextResponse.json({ error: 'Invalid' }, { status: 400 });
  const [row] = await db.update(schema.bookings).set(p.data).where(eq(schema.bookings.id, Number(params.id))).returning(); return NextResponse.json(row ?? null);
}
