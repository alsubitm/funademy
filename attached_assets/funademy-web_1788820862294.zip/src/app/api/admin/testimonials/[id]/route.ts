import { NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
const Patch = z.object({ quoteAr: z.string().max(600).optional(), quoteEn: z.string().max(600).optional(), whoAr: z.string().max(80).optional(), whoEn: z.string().max(80).optional(), approved: z.coerce.boolean().optional(), sortOrder: z.coerce.number().int().optional() });
export async function PATCH(req: Request, { params }: { params: { id: string } }) { const g = requireAdmin(); if (g) return g; const p = Patch.safeParse(await req.json().catch(() => null)); if (!p.success) return NextResponse.json({ error: 'Invalid' }, { status: 400 }); const [row] = await db.update(schema.testimonials).set(p.data).where(eq(schema.testimonials.id, Number(params.id))).returning(); return NextResponse.json(row ?? null); }
export async function DELETE(_: Request, { params }: { params: { id: string } }) { const g = requireAdmin(); if (g) return g; await db.delete(schema.testimonials).where(eq(schema.testimonials.id, Number(params.id))); return NextResponse.json({ ok: true }); }
