import { NextResponse } from 'next/server';
import { z } from 'zod';
import { asc } from 'drizzle-orm';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
export const dynamic = 'force-dynamic';
const T = z.object({ quoteAr: z.string().min(2).max(600), quoteEn: z.string().min(2).max(600), whoAr: z.string().min(2).max(80), whoEn: z.string().min(2).max(80), approved: z.coerce.boolean().default(false), sortOrder: z.coerce.number().int().default(0) });
export async function GET() { const g = requireAdmin(); if (g) return g; return NextResponse.json(await db.select().from(schema.testimonials).orderBy(asc(schema.testimonials.sortOrder))); }
export async function POST(req: Request) { const g = requireAdmin(); if (g) return g; const p = T.safeParse(await req.json().catch(() => null)); if (!p.success) return NextResponse.json({ error: 'Invalid' }, { status: 400 }); const [row] = await db.insert(schema.testimonials).values(p.data).returning(); return NextResponse.json(row, { status: 201 }); }
