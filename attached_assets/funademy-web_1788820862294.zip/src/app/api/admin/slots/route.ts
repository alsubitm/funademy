import { NextResponse } from 'next/server';
import { z } from 'zod';
import { asc } from 'drizzle-orm';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
export const dynamic = 'force-dynamic';
const Slot = z.object({ programSlug: z.string().min(2).max(64), weekday: z.coerce.number().int().min(0).max(6), time: z.string().regex(/^\d{2}:\d{2}$/), capacity: z.coerce.number().int().min(1).max(50).default(12), seatsLeft: z.coerce.number().int().min(0).max(50).default(12), formatAr: z.string().max(60).default('أونلاين مباشر'), formatEn: z.string().max(60).default('live online'), isOpen: z.coerce.boolean().default(true), startsOn: z.string().max(10).nullable().optional() });
export async function GET() { const g = requireAdmin(); if (g) return g; return NextResponse.json(await db.select().from(schema.slots).orderBy(asc(schema.slots.weekday), asc(schema.slots.time))); }
export async function POST(req: Request) {
  const g = requireAdmin(); if (g) return g;
  const p = Slot.safeParse(await req.json().catch(() => null)); if (!p.success) return NextResponse.json({ error: 'Invalid', issues: p.error.flatten().fieldErrors }, { status: 400 });
  const [row] = await db.insert(schema.slots).values(p.data).returning(); return NextResponse.json(row, { status: 201 });
}
