import { NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
const Patch = z.object({ programSlug: z.string().min(2).max(64).optional(), weekday: z.coerce.number().int().min(0).max(6).optional(), time: z.string().regex(/^\d{2}:\d{2}$/).optional(), capacity: z.coerce.number().int().min(1).max(50).optional(), seatsLeft: z.coerce.number().int().min(0).max(50).optional(), formatAr: z.string().max(60).optional(), formatEn: z.string().max(60).optional(), isOpen: z.coerce.boolean().optional(), startsOn: z.string().max(10).nullable().optional() });
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const g = requireAdmin(); if (g) return g;
  const p = Patch.safeParse(await req.json().catch(() => null)); if (!p.success) return NextResponse.json({ error: 'Invalid' }, { status: 400 });
  const [row] = await db.update(schema.slots).set(p.data).where(eq(schema.slots.id, Number(params.id))).returning(); return NextResponse.json(row ?? null);
}
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const g = requireAdmin(); if (g) return g;
  await db.delete(schema.slots).where(eq(schema.slots.id, Number(params.id))); return NextResponse.json({ ok: true });
}
