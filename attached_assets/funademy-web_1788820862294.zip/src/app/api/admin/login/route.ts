import { NextResponse } from 'next/server';
import { timingSafeEqual } from 'crypto';
import { adminCookie, signToken } from '@/lib/auth';
import { allow, ipHash } from '@/lib/ratelimit';
export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'local';
  if (!allow('login:' + ipHash(ip), 10, 15 * 60_000)) return NextResponse.json({ error: 'Too many attempts' }, { status: 429 });
  const { password } = await req.json().catch(() => ({ password: '' }));
  const expected = process.env.ADMIN_PASSWORD || '';
  const ok = expected.length > 0 && typeof password === 'string' && password.length === expected.length && timingSafeEqual(Buffer.from(password), Buffer.from(expected));
  if (!ok) return NextResponse.json({ error: 'Wrong password' }, { status: 401 });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(adminCookie(signToken(Date.now() + 12 * 3600_000)));
  return res;
}
