import { NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
const Patch = z.object({ qAr: z.string().max(300).optional(), qEn: z.string().max(300).optional(), aAr: z.string().max(1200).optional(), aEn: z.string().max(1200).optional(), page: z.string().max(64).optional(), sortOrder: z.coerce.number().int().optional(), active: z.coerce.boolean().optional() });
export async function PATCH(req: Request, { params }: { params: { id: string } }) { const g = requireAdmin(); if (g) return g; const p = Patch.safeParse(await req.json().catch(() => null)); if (!p.success) return NextResponse.json({ error: 'Invalid' }, { status: 400 }); const [row] = await db.update(schema.faqs).set(p.data).where(eq(schema.faqs.id, Number(params.id))).returning(); return NextResponse.json(row ?? null); }
export async function DELETE(_: Request, { params }: { params: { id: string } }) { const g = requireAdmin(); if (g) return g; await db.delete(schema.faqs).where(eq(schema.faqs.id, Number(params.id))); return NextResponse.json({ ok: true }); }
