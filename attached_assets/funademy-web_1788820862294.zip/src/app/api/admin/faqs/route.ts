import { NextResponse } from 'next/server';
import { z } from 'zod';
import { asc } from 'drizzle-orm';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
export const dynamic = 'force-dynamic';
const F = z.object({ qAr: z.string().min(2).max(300), qEn: z.string().min(2).max(300), aAr: z.string().min(2).max(1200), aEn: z.string().min(2).max(1200), page: z.string().max(64).default('home'), sortOrder: z.coerce.number().int().default(0), active: z.coerce.boolean().default(true) });
export async function GET() { const g = requireAdmin(); if (g) return g; return NextResponse.json(await db.select().from(schema.faqs).orderBy(asc(schema.faqs.sortOrder))); }
export async function POST(req: Request) { const g = requireAdmin(); if (g) return g; const p = F.safeParse(await req.json().catch(() => null)); if (!p.success) return NextResponse.json({ error: 'Invalid' }, { status: 400 }); const [row] = await db.insert(schema.faqs).values(p.data).returning(); return NextResponse.json(row, { status: 201 }); }
