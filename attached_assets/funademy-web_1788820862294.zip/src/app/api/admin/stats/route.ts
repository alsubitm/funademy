import { NextResponse } from 'next/server';
import { sql } from 'drizzle-orm';
import { db, schema } from '@/lib/db';
import { requireAdmin } from '@/lib/admin';
export const dynamic = 'force-dynamic';
export async function GET() {
  const g = requireAdmin(); if (g) return g;
  const byStatus = await db.select({ status: schema.bookings.status, n: sql<number>`count(*)::int` }).from(schema.bookings).groupBy(schema.bookings.status);
  const byProgram = await db.select({ program: schema.bookings.programSlug, n: sql<number>`count(*)::int` }).from(schema.bookings).groupBy(schema.bookings.programSlug);
  const events30d = await db.select({ name: schema.events.name, n: sql<number>`count(*)::int` }).from(schema.events).where(sql`${schema.events.createdAt} > now() - interval '30 days'`).groupBy(schema.events.name);
  return NextResponse.json({ byStatus, byProgram, events30d });
}
