import { NextResponse } from 'next/server';
import { z } from 'zod';
import { eq } from 'drizzle-orm';
import { db, schema } from '@/lib/db';
import { allow, ipHash } from '@/lib/ratelimit';
import { notifyBooking } from '@/lib/notify';

const Body = z.object({
  parentName: z.string().trim().min(2).max(80),
  phone: z.string().trim().regex(/^[+0-9 ()-]{9,20}$/),
  childAge: z.coerce.number().int().min(4).max(18),
  programSlug: z.string().min(2).max(64),
  preferredTime: z.string().max(60).default(''),
  city: z.string().trim().max(60).default('الرياض'),
  notes: z.string().trim().max(600).default(''),
  locale: z.enum(['ar', 'en']).default('ar'),
  website: z.string().max(0).optional(), // honeypot must be empty
});

export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'local';
  const key = ipHash(ip);
  if (!allow('book:' + key, 5, 10 * 60_000)) return NextResponse.json({ error: 'Too many requests' }, { status: 429 });
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'Invalid form', issues: parsed.error.flatten().fieldErrors }, { status: 400 });
  const d = parsed.data;
  const program = (await db.select().from(schema.programs).where(eq(schema.programs.slug, d.programSlug)).limit(1))[0];
  if (!program) return NextResponse.json({ error: 'Unknown program' }, { status: 400 });
  const [row] = await db.insert(schema.bookings).values({
    parentName: d.parentName, phone: d.phone.replace(/\s+/g, ' '), childAge: d.childAge, programSlug: d.programSlug, preferredTime: d.preferredTime,
    city: d.city || 'الرياض', notes: d.notes, locale: d.locale, source: 'site', ipHash: key, userAgent: (req.headers.get('user-agent') || '').slice(0, 200),
  }).returning();
  await db.insert(schema.events).values({ name: 'trial_form_submit', page: '/book', locale: d.locale, programSlug: d.programSlug, meta: { id: row.id } });
  notifyBooking(row, program.name).catch(() => {});
  return NextResponse.json({ ok: true, id: row.id }, { status: 201 });
}
