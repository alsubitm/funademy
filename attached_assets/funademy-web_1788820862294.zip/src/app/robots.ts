import type { MetadataRoute } from 'next';
export default function robots(): MetadataRoute.Robots {
  const site = process.env.SITE_URL || 'https://funademy.io';
  return { rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/en/admin', '/api/'] }], sitemap: `${site}/sitemap.xml` };
}
