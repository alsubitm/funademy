import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { MobileCta } from '@/components/MobileCta';
import { Analytics } from '@/components/Analytics';
import { DICT, dir, isLocale, type Locale } from '@/lib/i18n';

export const dynamic = 'force-dynamic';


export function generateMetadata({ params }: { params: { locale: string } }): Metadata {
  const locale = (isLocale(params.locale) ? params.locale : 'ar') as Locale;
  const site = process.env.SITE_URL || 'https://funademy.io';
  const title = locale === 'ar' ? 'FunAdemy — حيث تلتقي المتعة بالأكاديمية | برامج هندسة ورياضيات وعلوم مباشرة للأعمار 4–18' : 'FunAdemy — Where fun meets academy | Live engineering, math and science programs for ages 4–18';
  const description = locale === 'ar' ? 'FunAdemy: أكاديمية هندسية مرخّصة في الرياض — حصص مباشرة أونلاين وحضورية للأطفال من 4 إلى 18 سنة: ميكانيكا وروبوتات وبرمجة، وبرنامج SkyLab للرياضيات والعلوم. الحصة الأولى مجانية.' : 'FunAdemy: a licensed engineering academy in Riyadh — live online and in-person classes for ages 4–18: mechanics, robotics and coding, plus the SkyLab math and science program. First class free.';
  return {
    metadataBase: new URL(site), title: { default: title, template: '%s · FunAdemy' }, description,
    alternates: { canonical: locale === 'ar' ? '/' : '/en', languages: { ar: '/', en: '/en' } },
    openGraph: { title, description, type: 'website', locale: locale === 'ar' ? 'ar_SA' : 'en_US', siteName: 'FunAdemy', images: ['/og.png'] },
    twitter: { card: 'summary_large_image', title, description },
    icons: { icon: '/icon.svg' },
  };
}

export default function LocaleLayout({ children, params }: { children: React.ReactNode; params: { locale: string } }) {
  if (!isLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const t = DICT[locale];
  const org = { '@context': 'https://schema.org', '@type': 'EducationalOrganization', name: 'FunAdemy', legalName: 'Falcon Eye Ltd', url: process.env.SITE_URL || 'https://funademy.io', email: 'admin@funademy.io', address: { '@type': 'PostalAddress', addressLocality: 'Riyadh', addressCountry: 'SA' }, slogan: t.tagline };
  return (
    <html lang={locale} dir={dir(locale)}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Baloo+Bhaijaan+2:wght@700;800&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(org) }} />
      </head>
      <body>
        <Header locale={locale} />
        <main id="main">{children}</main>
        <Footer locale={locale} />
        <MobileCta locale={locale} />
        <Analytics locale={locale} />
      </body>
    </html>
  );
}
