import type { Metadata } from 'next';
import { DICT, href, type Locale } from '@/lib/i18n';
export function generateMetadata({ params }: { params: { locale: Locale } }): Metadata { const t = DICT[params.locale]; return { title: t.campaign.h, description: t.campaign.p }; }
export default function Campaign({ params }: { params: { locale: Locale } }) {
  const locale = params.locale; const t = DICT[locale];
  const ev = { '@context': 'https://schema.org', '@type': 'Event', name: 'Mini Watan', startDate: '2027-09-23', location: { '@type': 'Place', name: 'Riyadh', address: { '@type': 'PostalAddress', addressLocality: 'Riyadh', addressCountry: 'SA' } }, organizer: { '@type': 'Organization', name: 'FunAdemy' } };
  const cols = ['#1C54CB', '#6D28D9', '#FFCA17']; const tcols = ['#1C54CB', '#6D28D9', '#B8930A'];
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ev) }} />
      <div className="wrap pagehead pattern"><div className="kicker">ROUTE · NATIONAL CAMPAIGN 2026–2027</div><h1>{t.campaign.h}</h1><p className="lede">{t.campaign.pageP}</p></div>
      <section className="pg"><div className="wrap">
        <div className="route">
          <svg viewBox="0 0 1200 260" aria-hidden="true">
            <path d="M80 200 Q 300 40 460 150 T 820 120 T 1120 70" fill="none" stroke="#A78BFA" strokeWidth="3" strokeDasharray="4 12" strokeLinecap="round" />
            <g fontFamily="Baloo Bhaijaan 2, IBM Plex Sans Arabic, sans-serif" fontSize="22" fontWeight="800" textAnchor="middle">
              {[[80, 200], [460, 150], [820, 120]].map(([x, y], i) => <g key={i}><circle cx={x} cy={y} r="22" fill={cols[i]} /><text x={x} y={y + 48} fill={tcols[i]}>{t.campaign.phases[i]}</text><text x={x} y={y - 40} fontFamily="IBM Plex Mono, monospace" fontSize="12" fontWeight="500" fill="#5C6B99">{t.campaign.terms[i].toUpperCase()}</text></g>)}
              <circle cx="1120" cy="70" r="26" fill="#0E6B3A" stroke="#fff" strokeWidth="3" /><text x="1120" y="122" fill="#0E6B3A">{t.campaign.phases[3]}</text><text x="1120" y="30" fontFamily="IBM Plex Mono, monospace" fontSize="12" fontWeight="500" fill="#0E6B3A">NATIONAL DAY 2027</text>
            </g>
          </svg>
          <div className="mw">
            <div className="mono" style={{ color: '#0E6B3A' }}>MINI WATAN · 23 SEPTEMBER 2027</div>
            <h3 style={{ fontSize: '1.4rem', margin: '6px 0' }}>{t.campaign.mwH}</h3>
            <p className="note" style={{ margin: 0 }}>{t.campaign.mwP}</p>
            <p style={{ margin: '12px 0 0' }}><a className="btn btn-gold" href={href(locale, '/schools')}>{t.campaign.mwCta}</a></p>
          </div>
        </div>
      </div></section>
    </>
  );
}
