import type { Metadata } from 'next';
import { QuickBook } from '@/components/QuickBook';
import { DICT, type Locale } from '@/lib/i18n';
import { getPrograms } from '@/lib/queries';
export function generateMetadata({ params }: { params: { locale: Locale } }): Metadata { const t = DICT[params.locale]; return { title: t.nav.pricing, description: `1,380 ${t.price.unit} · ${t.price.free}` }; }
export default async function Pricing({ params }: { params: { locale: Locale } }) {
  const locale = params.locale; const t = DICT[locale]; const ar = locale === 'ar';
  const programs = await getPrograms();
  return (
    <>
      <div className="wrap pagehead pattern"><div className="kicker">FARE · ONE PRICE</div><h1>{t.price.h}</h1><p className="lede">{t.price.free}</p></div>
      <section className="pg"><div className="wrap">
        <div className="ticket">
          <div className="left">
            <div className="tear">FUNADEMY · MONTHLY FARE</div>
            <div className="fare">1,380 <small>{t.price.unit}</small></div>
            {t.price.inc.map(([k, v]) => <div className="kv" key={k}><span>{k}</span><b>{v}</b></div>)}
            <h4 style={{ marginTop: 18 }}>{t.price.payH}</h4><p style={{ color: '#3A4160' }}>{t.price.payP}</p>
            <h4>{t.price.exH}</h4><p style={{ color: '#3A4160' }}>{t.price.exP}</p>
          </div>
          <div className="right">
            <div className="tear">✂ TEAR HERE · {ar ? <span style={{ fontFamily: 'var(--body)', letterSpacing: 0 }}>التذكرة الأولى</span> : 'FIRST TICKET'}</div>
            <h3>{t.price.free}</h3><p style={{ margin: 0, color: '#3A2E00' }}>{t.price.tryP}</p>
            <QuickBook locale={locale} programs={programs} />
          </div>
        </div>
      </div></section>
    </>
  );
}
