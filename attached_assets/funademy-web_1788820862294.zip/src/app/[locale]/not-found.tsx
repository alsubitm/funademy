import { DICT, href } from '@/lib/i18n';
export default function NotFound() {
  const t = DICT.ar;
  return (
    <div className="wrap pagehead" style={{ minHeight: '60vh' }}><div>
      <h1>{t.notfound.h}</h1><div className="kicker">404 · NO SUCH RUNWAY</div><p className="lede">{t.notfound.p}</p>
      <p><a className="btn btn-gold" href={href('ar', '/')}>{t.notfound.home}</a> <a className="btn btn-ghost" href={href('ar', '/book')}>{t.nav.book}</a></p>
    </div></div>
  );
}
