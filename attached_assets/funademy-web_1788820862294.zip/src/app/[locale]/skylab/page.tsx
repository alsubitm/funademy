import type { Metadata } from 'next';
import { StemCard } from '@/components/StemCard';
import { Countdown } from '@/components/Countdown';
import { DICT, href, type Locale } from '@/lib/i18n';
import { getPrograms, getSetting } from '@/lib/queries';
import { MISSIONS } from '@/lib/missions';
export function generateMetadata({ params }: { params: { locale: Locale } }): Metadata { const t = DICT[params.locale]; return { title: t.skylab.h, description: t.skylab.p }; }

export default async function SkyLab({ params }: { params: { locale: Locale } }) {
  const locale = params.locale; const t = DICT[locale]; const ar = locale === 'ar';
  const [all, pilot] = await Promise.all([getPrograms(), getSetting('pilot_start')]);
  const sky = all.filter(p => p.track === 'skylab');
  const arNames = ['فريق الأرض', 'الإقلاع', 'الانسياب', 'التحليق', 'المدار'];
  return (
    <>
      <div className="wrap pagehead pattern"><div className="kicker">PART B · SKYLAB · ORIGINAL FUNADEMY PROGRAM</div><h1>{t.skylab.h}</h1><p className="lede">{t.skylab.p}</p></div>
      <section className="pg"><div className="wrap">
        <div className="sec-head"><span className="n">01 · FLIGHT PLAN</span><h2 style={{ fontSize: '1.7rem' }}>{t.skylab.arcH}</h2></div>
        <div className="wps" style={{ marginTop: 0 }}>{t.skylab.arc.map((s, i) => <div className="wp" key={s}><b style={i === 3 ? { color: 'var(--gold)' } : undefined}>{i + 1} · {s}</b></div>)}</div>
        <div className="sec-head" style={{ marginTop: 44 }}><span className="n">02 · ALTITUDES</span><h2 style={{ fontSize: '1.7rem' }}>{t.skylab.altH}</h2></div>
        <table className="spec"><thead><tr>{t.skylab.th.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>
          {sky.map((p, i) => <tr key={p.slug}><td><b>ALT {i + 1} · {p.name.replace('SkyLab ', '')}</b> {ar && <span>{arNames[i]}</span>}</td><td>{p.ageMin}–{p.ageMax}</td><td>{p.sessionMin} {t.rail.min}{i === 0 ? ` · ${t.skylab.parent}` : ''}</td><td>{(ar ? p.oneLinerAr : p.oneLinerEn).replace(/^[^—]+— /, '')}</td></tr>)}
        </tbody></table>
        <div className="grid g3" style={{ marginTop: 28 }}>{t.skylab.cards.map(([h, p]) => <div className="paper" key={h}><h4>{h}</h4><p style={{ fontSize: '.92rem' }}>{p}</p></div>)}</div>
        <div className="sec-head" style={{ marginTop: 44 }}><span className="n">03 · YEAR A · 50 MISSIONS</span><h2 style={{ fontSize: '1.7rem' }}>{ar ? 'خمسون مهمة في السنة الأولى — عشر لكل ارتفاع' : 'Fifty missions in Year A — ten per altitude'}</h2></div>
        <div className="missions">{sky.map((p, i) => <div className="mlevel" key={p.slug} style={{ borderTopColor: ['var(--S)', 'var(--T)', 'var(--E)', 'var(--purple)', 'var(--navy)'][i] }}><h4>ALT {i + 1} · {p.name.replace('SkyLab ', '')}</h4><small>{ar ? arNames[i] : ''} {p.ageMin}–{p.ageMax} · {p.sessionMin} {t.rail.min}</small><ol>{(MISSIONS[p.slug] || []).map(m => <li key={m.en}><b>{ar ? m.ar : m.en}</b>{ar ? '' : ''}</li>)}</ol></div>)}</div>
        <div className="sec-head" style={{ marginTop: 44 }}><span className="n">04 · CHOOSE AN ALTITUDE</span><h2 style={{ fontSize: '1.7rem' }}>{ar ? 'اختر ارتفاع طفلك' : "Choose your child's altitude"}</h2></div>
        <div className="grid g2">{sky.map((p, i) => <StemCard key={p.slug} p={p} locale={locale} />)}</div>
        <div className="engine" style={{ marginTop: 28, borderColor: 'rgba(255,202,23,.45)' }}>
          <div className="part" style={{ color: 'var(--gold)' }}>T-MINUS · MISSION 1</div>
          <h3>{t.skylab.pilotH}</h3><p className="note">{t.skylab.pilotP}</p>
          <Countdown target={pilot || '2026-10-04T17:00:00+03:00'} labels={ar ? ['يومًا', 'ساعة', 'دقيقة', 'ثانية'] : ['DAYS', 'HOURS', 'MIN', 'SEC']} />
          <a className="btn btn-gold" href={href(locale, '/book?program=skylab-lift-off')}>{t.skylab.pilotCta}</a>
        </div>
      </div></section>
    </>
  );
}
