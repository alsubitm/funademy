import type { Metadata } from 'next';
import { StemCard } from '@/components/StemCard';
import { DICT, href, type Locale } from '@/lib/i18n';
import { getPrograms } from '@/lib/queries';
export function generateMetadata({ params }: { params: { locale: Locale } }): Metadata { const t = DICT[params.locale]; return { title: t.programs.h, description: t.programs.p }; }
const PATH = ['big-builders', 'smartivo', 'bricks-challenge', 'algoplay', 'galileo-technic', 'robotoys', 'algoc'];
const BAR: Record<string, string> = { S: 'var(--S)', T: 'var(--T)', E: 'var(--E)', M: 'var(--navy)' };
export default async function Programs({ params }: { params: { locale: Locale } }) {
  const locale = params.locale; const t = DICT[locale]; const ar = locale === 'ar';
  const eng = (await getPrograms()).filter(p => p.track === 'engineering');
  const fields = Array.from(new Set(eng.map(p => (ar ? p.fieldAr : p.fieldEn))));
  const path = PATH.map(slug => eng.find(p => p.slug === slug)).filter(Boolean);
  return (
    <>
      <div className="wrap pagehead pattern"><div className="kicker">ENGINEERING · TECHNOLOGY · 7 PROGRAMS · IN PERSON · RIYADH</div><h1>{t.programs.h}</h1><p className="lede">{ar ? 'سبعة برامج حضورية في قاعة FunAdemy في الرياض، في ثلاثة مجالات. مسار التعلم يصعد مع العمر:' : 'Seven in-person programs in the FunAdemy classroom in Riyadh, in three fields. The learning path climbs with age:'}</p></div>
      <section className="pg"><div className="wrap">
        <div className="path">{path.map(p => p && <a key={p.slug} href={href(locale, `/programs/${p.slug}`)}><div className="bar" style={{ background: BAR[p.stem.split(',')[0]] }} /><b>{p.name}</b><small>{p.ageMin}–{p.ageMax} · {p.sessionMin} {t.rail.min}</small></a>)}</div>
        {fields.map(f => { const first = eng.find(p => (ar ? p.fieldAr : p.fieldEn) === f)!; const k = first.stem.split(',')[0]; return (
          <div key={f}><div className="fieldhead"><span className="dot" style={{ background: BAR[k] }} /><h2>{f}</h2></div>
            <div className="grid g2">{eng.filter(p => (ar ? p.fieldAr : p.fieldEn) === f).map(p => <StemCard key={p.slug} p={p} locale={locale} />)}</div></div>); })}
        <p className="note" style={{ marginTop: 24 }}>{t.programs.credit}</p>
        <p><a className="btn btn-gold" href={href(locale, '/book')}>{t.programs.cta}</a></p>
      </div></section>
    </>
  );
}
