import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { StemCard } from '@/components/StemCard';
import { DICT, WEEKDAYS, href, type Locale } from '@/lib/i18n';
import { Pills } from '@/components/StemCard';
import { getProgram, getPrograms, getSlotsFor } from '@/lib/queries';

export async function generateMetadata({ params }: { params: { locale: Locale; slug: string } }): Promise<Metadata> {
  const p = await getProgram(params.slug); if (!p) return {};
  const ar = params.locale === 'ar';
  return { title: `${p.name} · ${ar ? 'الأعمار' : 'ages'} ${p.ageMin}–${p.ageMax}`, description: ar ? p.oneLinerAr : p.oneLinerEn };
}

export default async function ProgramPage({ params }: { params: { locale: Locale; slug: string } }) {
  const locale = params.locale; const t = DICT[locale]; const ar = locale === 'ar';
  const p = await getProgram(params.slug); if (!p || p.track !== 'engineering') notFound();
  const [all, mySlots] = await Promise.all([getPrograms(), getSlotsFor(p.slug)]);
  const also = all.filter(x => x.slug !== p.slug && x.ageMax >= p.ageMin && x.ageMin <= p.ageMax).slice(0, 4);
  const course = { '@context': 'https://schema.org', '@type': 'Course', name: p.name, description: ar ? p.oneLinerAr : p.oneLinerEn, provider: { '@type': 'Organization', name: 'FunAdemy' } };
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(course) }} />
      <div className="wrap pagehead">
        <div className="kicker" style={{ display: "flex", alignItems: "center", gap: 12 }}>{ar ? p.fieldAr : p.fieldEn} <Pills stem={p.stem} /></div>
        <div className="eng-grid" style={{ alignItems: 'end' }}>
          <div><h1>{p.name}</h1><p className="lede">{ar ? p.oneLinerAr : p.oneLinerEn}</p>
            <div className="ctas"><a className="btn btn-gold" href={href(locale, `/book?program=${p.slug}`)}>{t.programs.bookThis}</a><a className="btn btn-line" href={href(locale, '/programs')}>{t.programs.back}</a></div></div>
          <div className="facts">
            <div className="f"><b>{p.ageMin}–{p.ageMax}</b><span>{ar ? 'الأعمار' : 'AGES'}</span></div>
            <div className="f"><b>{p.sessionMin}</b><span>{ar ? 'دقيقة' : 'MIN'}</span></div>
            <div className="f"><b>{p.classCap}</b><span>{ar ? 'مقعدًا كحد أقصى' : 'SEATS MAX'}</span></div>
            <div className="f"><b style={{ fontSize: '1.1rem' }}>{ar ? p.formatAr : p.formatEn}</b><span>GATE</span></div>
          </div>
        </div>
      </div>
      <section className="pg"><div className="wrap">
        <div className="engine" style={{ marginBottom: 26 }}><div className="part">BRIEFING</div><p style={{ margin: '8px 0 0', fontSize: '1.05rem' }}>{ar ? p.descriptionAr : p.descriptionEn}</p></div>
        <div className="sec-head"><span className="n">01 · BUILD LOG</span><h2 style={{ fontSize: '1.6rem' }}>{t.programs.builds}</h2></div>
        <div className="buildlist">{(ar ? p.builds.ar : p.builds.en).map(b => <div className="build" key={b}><i />{b}</div>)}</div>
        <div className="sec-head" style={{ marginTop: 40 }}><span className="n">02 · A {p.sessionMin}-MINUTE SESSION</span><h2 style={{ fontSize: '1.6rem' }}>{t.programs.session}</h2></div>
        <div className="timeline">{(() => { const m = p.sessionMin; const parts = [Math.round(m * .4), Math.round(m * .25), Math.round(m * .2), m - Math.round(m * .4) - Math.round(m * .25) - Math.round(m * .2)]; const desc = ar ? ['يبني النموذج أو يكتب البرنامج بيديه', 'يشغّله ويقيس ما يحدث', 'يغيّر شيئًا واحدًا ويعيد المحاولة', 'يشرح للمجموعة لماذا يعمل'] : ['Builds the model or writes the program', 'Runs it and measures what happens', 'Changes one thing and tries again', 'Explains to the group why it works']; return t.programs.sessionSteps.map((sName, i) => <div key={sName}><em>{parts[i]} {ar ? 'د' : 'min'}</em><b>{i + 1} · {sName}</b><span>{desc[i]}</span></div>); })()}</div>
        <div className="sec-head" style={{ marginTop: 40 }}><span className="n">03 · WHO IT IS FOR</span><h2 style={{ fontSize: '1.6rem' }}>{ar ? 'لمن هذا البرنامج' : 'Who it is for'}</h2></div>
        <div className="grid g3">
          <div className="paper"><h4>{ar ? 'العمر' : 'Age'}</h4><p>{ar ? `من ${p.ageMin} إلى ${p.ageMax} سنة — نضع الطفل في المجموعة المناسبة لمستواه بعد الحصة التجريبية.` : `Ages ${p.ageMin} to ${p.ageMax} — we place the child in the right group after the trial class.`}</p></div>
          <div className="paper"><h4>{ar ? 'لا خبرة مطلوبة' : 'No experience needed'}</h4><p>{ar ? 'كل حصة تبدأ من الصفر بنموذج جديد؛ الطفل الذي يحب أن يبني أو يسأل «كيف يعمل؟» جاهز.' : 'Every session starts from zero with a new model; a child who likes to build or asks "how does it work?" is ready.'}</p></div>
          <div className="paper"><h4>{ar ? 'المكان' : 'Where'}</h4><p>{ar ? 'حضوريًا في قاعة FunAdemy في الرياض، في مجموعة لا تتجاوز ' + p.classCap + ' طالبًا.' : 'In person in the FunAdemy classroom in Riyadh, in a group of no more than ' + p.classCap + '.'}</p></div>
        </div>
        <div className="sec-head" style={{ marginTop: 40 }}><span className="n">04 · THIS WEEK</span><h2 style={{ fontSize: '1.6rem' }}>{t.programs.slots}</h2></div>
        {mySlots.length ? mySlots.map(s => <div className="slot" key={s.id}><span><b>{WEEKDAYS[locale][s.weekday]} {s.time}</b> · {ar ? s.formatAr : s.formatEn}</span><span className="seats">{s.seatsLeft > 0 ? `${s.seatsLeft} ${t.ticker.seats}` : (ar ? 'قائمة انتظار' : 'WAITLIST')}</span></div>) : <p className="note">{t.ticker.empty}</p>}
        {also.length > 0 && <><div className="sec-head" style={{ marginTop: 40 }}><span className="n">05 · ALSO FOR THIS AGE</span><h2 style={{ fontSize: '1.6rem' }}>{t.programs.also}</h2></div>
          <div className="grid g2">{also.map(x => <StemCard key={x.slug} p={x} locale={locale} />)}</div></>}
        <p className="note" style={{ marginTop: 28 }}>{t.programs.cert}</p>
        <p><a className="btn btn-gold" href={href(locale, `/book?program=${p.slug}`)}>{t.programs.bookThis}</a></p>
      </div></section>
    </>
  );
}
