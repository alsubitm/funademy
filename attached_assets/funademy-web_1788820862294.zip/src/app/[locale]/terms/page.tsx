import { DICT, type Locale } from '@/lib/i18n';
export default function Terms({ params }: { params: { locale: Locale } }) {
  const t = DICT[params.locale]; const ar = params.locale === 'ar';
  return (
    <>
      <div className="wrap pagehead"><div className="kicker">TERMS OF ENROLMENT</div><h1>{t.legal.termsH}</h1></div>
      <section className="pg"><div className="wrap"><div className="paper legal">{ar ? (<>
        <h3>الاشتراك</h3><p>الاشتراك شهري: 1,380 ريالًا للطفل في البرنامج الواحد، ويشمل 4–6 حصص مباشرة حسب البرنامج. يمكن إيقاف الاشتراك في نهاية أي شهر بإشعار قبل أسبوع.</p>
        <h3>الحصة التجريبية</h3><p>الحصة الأولى مجانية وبلا التزام.</p>
        <h3>الخصومات</h3><p>خصم 10٪ لكل طفل إضافي من العائلة نفسها.</p>
        <h3>الحقيبة المنزلية</h3><p>حقيبة SkyLab المنزلية مشمولة مع التزام ثلاثة أشهر، وتبقى ملكًا للطالب.</p>
        <h3>الفواتير</h3><p>تُصدر فاتورة إلكترونية معتمدة مع كل دفعة.</p>
        <h3>الصور والتسجيل</h3><p>لا يُنشر أي محتوى يظهر فيه طفل دون موافقة خطية من ولي الأمر.</p>
      </>) : (<>
        <h3>Subscription</h3><p>Monthly: SAR 1,380 per child per program, including 4–6 live sessions depending on the program. Pause at the end of any month with a week&apos;s notice.</p>
        <h3>Trial class</h3><p>The first class is free and without commitment.</p>
        <h3>Discounts</h3><p>10% off for every additional child from the same family.</p>
        <h3>Home kit</h3><p>The Home SkyLab Kit is included with a three-month commitment and remains the student&apos;s.</p>
        <h3>Invoices</h3><p>A compliant e-invoice is issued with every payment.</p>
        <h3>Photos and recordings</h3><p>No content showing a child is published without the parent&apos;s written consent.</p>
      </>)}</div></div></section>
    </>
  );
}
