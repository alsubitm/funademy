import type { Metadata } from 'next';
import { BookingForm } from '@/components/BookingForm';
import { DICT, type Locale } from '@/lib/i18n';
import { getPrograms } from '@/lib/queries';
export function generateMetadata({ params }: { params: { locale: Locale } }): Metadata { const t = DICT[params.locale]; return { title: t.book.h, description: t.book.p }; }
export default async function Book({ params, searchParams }: { params: { locale: Locale }; searchParams: { program?: string } }) {
  const locale = params.locale; const t = DICT[locale];
  const programs = await getPrograms();
  return (
    <>
      <div className="wrap pagehead pattern"><div className="kicker">CHECK-IN · FREE TRIAL</div><h1>{t.book.h}</h1><p className="lede">{t.book.p}</p></div>
      <section className="pg"><div className="wrap bookgrid">
        <BookingForm locale={locale} programs={programs} preset={searchParams.program} />
        <div className="next">
          {(locale === 'ar' ? [['نتصل بك خلال 24 ساعة', 'نؤكد الموعد ونختار المجموعة المناسبة لعمر طفلك.'], ['الحصة التجريبية', 'حصة كاملة مع المعلم والمجموعة — حضوريًا في الرياض أو أونلاين في SkyLab.'], ['تقرر بهدوء', 'بعد الحصة نرسل لك انطباع المعلم؛ الاشتراك شهري ويمكن إيقافه نهاية أي شهر.'], ['تصل الحقيبة', 'في SkyLab تصل حقيبة التجارب إلى البيت قبل الحصة الأولى.']] : [['We call within 24 hours', 'We confirm the time and pick the right group for your child\'s age.'], ['The trial class', 'A full class with the teacher and the group — in person in Riyadh, or online in SkyLab.'], ['Decide calmly', 'After the class we send the teacher\'s impression; the subscription is monthly and pauses at any month end.'], ['The kit arrives', 'In SkyLab the experiment kit reaches the home before the first class.']]).map(([h, p], i) => <div key={h}><span className="n">{i + 1}</span><div><b>{h}</b><span>{p}</span></div></div>)}
        </div>
      </div></section>
    </>
  );
}
