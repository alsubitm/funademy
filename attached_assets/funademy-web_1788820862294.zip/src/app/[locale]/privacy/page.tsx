import { DICT, type Locale } from '@/lib/i18n';
export default function Privacy({ params }: { params: { locale: Locale } }) {
  const t = DICT[params.locale]; const ar = params.locale === 'ar';
  return (
    <>
      <div className="wrap pagehead"><div className="kicker">PDPL · PRIVACY</div><h1>{t.legal.privacyH}</h1></div>
      <section className="pg"><div className="wrap"><div className="paper legal">{ar ? (<>
        <p>تلتزم Falcon Eye Ltd (المشغّل لعلامة FunAdemy، السجل التجاري 4030388340، الرياض) بنظام حماية البيانات الشخصية في المملكة العربية السعودية.</p>
        <h3>ما الذي نجمعه</h3><p>عند حجز حصة تجريبية: اسم ولي الأمر ورقم الجوال وعمر الطفل والبرنامج والوقت المفضل والمدينة وأي ملاحظات تكتبها. لا نجمع بيانات الأطفال بأسمائهم عبر الموقع.</p>
        <h3>لماذا</h3><p>للتواصل معك وتأكيد الحصة التجريبية واختيار المجموعة المناسبة. لا نستخدم بياناتك لأي غرض آخر، ولا نبيعها ولا نشاركها مع أي طرف ثالث.</p>
        <h3>أين تُحفظ</h3><p>على خوادم داخل المملكة العربية السعودية، ولمدة لا تتجاوز 24 شهرًا من آخر تواصل، ما لم تصبح عميلًا فتنطبق شروط الاشتراك.</p>
        <h3>التحليلات</h3><p>نسجّل زيارات الصفحات ونقرات الحجز على خوادمنا فقط، دون ملفات تعريف تتبّع من أطراف ثالثة.</p>
        <h3>حقوقك</h3><p>يمكنك طلب الاطلاع على بياناتك أو تصحيحها أو حذفها في أي وقت عبر admin@funademy.io.</p>
      </>) : (<>
        <p>Falcon Eye Ltd (operating the FunAdemy brand, CR 4030388340, Riyadh) complies with the Personal Data Protection Law of the Kingdom of Saudi Arabia.</p>
        <h3>What we collect</h3><p>When you book a trial class: the parent&apos;s name, mobile number, the child&apos;s age, the program, preferred time, city and any notes you write. We do not collect children&apos;s names through the site.</p>
        <h3>Why</h3><p>To contact you, confirm the trial class and choose the right group. We use your data for nothing else, and we never sell or share it with third parties.</p>
        <h3>Where it is stored</h3><p>On servers inside the Kingdom of Saudi Arabia, for no longer than 24 months after the last contact, unless you become a customer, in which case the terms of enrolment apply.</p>
        <h3>Analytics</h3><p>We record page views and booking clicks on our own servers only, with no third-party tracking cookies.</p>
        <h3>Your rights</h3><p>You can ask to see, correct or delete your data at any time at admin@funademy.io.</p>
      </>)}</div></div></section>
    </>
  );
}
