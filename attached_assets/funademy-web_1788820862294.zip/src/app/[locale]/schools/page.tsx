import type { Metadata } from 'next';
import { DICT, type Locale } from '@/lib/i18n';
export function generateMetadata({ params }: { params: { locale: Locale } }): Metadata { const t = DICT[params.locale]; return { title: t.schools.h, description: t.schools.p }; }
export default function Schools({ params }: { params: { locale: Locale } }) {
  const t = DICT[params.locale];
  return (
    <>
      <div className="wrap pagehead pattern"><div className="kicker">GROUND OPERATIONS · SCHOOLS & PARTNERS</div><h1>{t.schools.h}</h1><p className="lede">{t.schools.p}</p></div>
      <section className="pg"><div className="wrap">
        <div className="grid g4">{t.schools.offers.map(([h, p], i) => <div className="engine" key={h}><div className="part">OFFER 0{i + 1}</div><h3 style={{ fontSize: '1.2rem', margin: '6px 0' }}>{h}</h3><p className="note" style={{ margin: 0 }}>{p}</p></div>)}</div>
        <p style={{ marginTop: 24 }}><a className="btn btn-gold" href="mailto:admin@funademy.io?subject=School%20proposal%20request">{t.schools.cta}</a></p>
      </div></section>
    </>
  );
}
