import { Playground } from '@/components/Playground';
import { Departures, type Departure } from '@/components/Departures';
import { StemMap } from '@/components/StemMap';
import { Countdown } from '@/components/Countdown';
import { QuickBook } from '@/components/QuickBook';
import { KiteFlight } from '@/components/KiteFlight';
import { LoopRing } from '@/components/LoopRing';
import { DICT, WEEKDAYS, href, WA, type Locale } from '@/lib/i18n';
import { getPrograms, getFaqs, getApprovedTestimonials, getOpenSlots, getSetting } from '@/lib/queries';

const PILLARS = [
  { k: 'S', ar: 'العلوم', en: 'Science', tryAr: 'جرّب تجربة الكثافة', tryEn: 'Try the density lab', progs: ['SkyLab 4–18', 'Big Builders 4–6'], bul: { ar: ['تجارب حقيقية من حقيبة البيت، مباشرة على الكاميرا', 'مهمة سعودية كل شهر: الظل، الماء، الصقر، الطاقة', 'من «يغرق أم يطفو» إلى ورقة بحثية تُناقَش'], en: ['Real experiments from the home kit, live on camera', 'A Saudi mission every month: shadow, water, falcon, energy', 'From "sink or float" to a defended research paper'] } },
  { k: 'T', ar: 'التقنية', en: 'Technology', tryAr: 'برمج الطيارة', tryEn: 'Code the kite', progs: ['Smartivo 4–6', 'AlgoPlay 6–10', 'RoboToys 9–12', 'AlgoC 13–18'], bul: { ar: ['برمجة من الأوامر الملموسة إلى الكود النصي', 'روبوتات بحساسات تقرأ وتقرر', 'حضوري في قاعة FunAdemy في الرياض'], en: ['Coding from tangible commands to text code', 'Robots with sensors that read and decide', 'In person in the FunAdemy classroom in Riyadh'] } },
  { k: 'E', ar: 'الهندسة', en: 'Engineering', tryAr: 'أدر التروس', tryEn: 'Turn the gears', progs: ['Big Builders 4–6', 'Bricks Challenge 6–10', 'Galileo Technic 7–10'], bul: { ar: ['تروس وروافع وبكرات — نماذج تتحرك بمحركات حقيقية', 'يبني الطفل، يشغّل، ويشرح لماذا يعمل', 'حضوري في الرياض'], en: ['Gears, levers and pulleys — models that move with real motors', 'The child builds, runs it, and explains why it works', 'In person in Riyadh'] } },
  { k: 'M', ar: 'الرياضيات', en: 'Math', tryAr: 'حرّك الشمس', tryEn: 'Move the sun', progs: ['Ground Crew 4–6', 'Lift-Off 7–9', 'Glide 10–12', 'Soar 13–15', 'Orbit 16–18'], bul: { ar: ['الرياضيات تفسّر بيانات التجربة — لا تُحفظ', 'من العدّ إلى الكسور والنسب والجبر والتفاضل', 'لا درجات: سجل طيران وشارات ويوم إطلاق'], en: ["Math explains the experiment's data — not memorised", 'From counting to fractions, ratios, algebra and calculus', 'No grades: a Flight Log, badges and a Launch Day'] } },
];

const SCENES = [
  { f: 'build', tag: 'E · BRICKS CHALLENGE', whereAr: 'الرياض', whereEn: 'RIYADH', ar: 'يبني نموذجًا بمحرك حقيقي', en: 'Building a model with a real motor' },
  { f: 'code', tag: 'T · ALGOPLAY', whereAr: 'الرياض', whereEn: 'RIYADH', ar: 'يبرمج روبوته الأول', en: 'Coding a first robot' },
  { f: 'experiment', tag: 'S · SKYLAB', whereAr: 'من البيت', whereEn: 'FROM HOME', ar: 'تجربة من حقيبة SkyLab على الكاميرا', en: 'A SkyLab kit experiment on camera' },
  { f: 'measure', tag: 'M · SKYLAB', whereAr: 'يوم الإطلاق', whereEn: 'LAUNCH DAY', ar: 'يعرض بياناته أمام الأهل', en: 'Presenting the data to the family' },
];

const ICONS: Record<string, JSX.Element> = {
  S: <svg width="26" height="26" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M9 3h6M10 3v6L4.5 19a1.5 1.5 0 0 0 1.3 2.2h12.4a1.5 1.5 0 0 0 1.3-2.2L14 9V3" /><path fill="currentColor" d="M7.5 16h9l2 3.5H5.5z" opacity=".8" /></svg>,
  T: <svg width="26" height="26" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16" /></svg>,
  E: <svg width="26" height="26" viewBox="0 0 24 24"><path fill="currentColor" d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.5-2-3.5-2.4 1a7.7 7.7 0 0 0-1.7-1L15 3.5h-4l-.4 2.5a7.7 7.7 0 0 0-1.7 1l-2.4-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2 1.5 2 3.5 2.4-1a7.7 7.7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.7 7.7 0 0 0 1.7-1l2.4 1 2-3.5L19.4 13zM13 15a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" /></svg>,
  M: <svg width="26" height="26" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M3 20h18M4 17c3-1 5-8 8-8s4 5 8 3" /><circle cx="12" cy="9" r="1.8" fill="currentColor" /></svg>,
};

export default async function Home({ params }: { params: { locale: Locale } }) {
  const locale = params.locale; const t = DICT[locale]; const ar = locale === 'ar';
  const [programs, faqs, quotes, slots, pilot] = await Promise.all([getPrograms(), getFaqs('home'), getApprovedTestimonials(), getOpenSlots(), getSetting('pilot_start')]);
  const by = (slug: string) => programs.find(p => p.slug === slug);
  const rows: Departure[] = slots.map(s => ({ time: `${WEEKDAYS.en[s.weekday].toUpperCase()} ${s.time}`, flight: by(s.programSlug)?.name || s.programSlug, gate: (by(s.programSlug)?.stem || '').replace(',', '·') + (s.formatEn.includes('Riyadh') ? ' · RYD' : ' · ONL'), seats: s.seatsLeft }));
  const faqLd = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faqs.map(f => ({ '@type': 'Question', name: ar ? f.qAr : f.qEn, acceptedAnswer: { '@type': 'Answer', text: ar ? f.aAr : f.aEn } })) };
  const loop = ar ? [['يبني', 'نموذج أو تجربة أو برنامج'], ['يختبر', 'يقيس ويسجّل النتيجة'], ['يحسّن', 'يغيّر شيئًا واحدًا ويعيد'], ['يعرض', 'يشرح للمجموعة — وللأهل في يوم الإطلاق']] : [['Build', 'A model, an experiment or a program'], ['Test', 'Measures and records the result'], ['Improve', 'Changes one thing and repeats'], ['Present', 'Explains to the group — and to the family on Launch Day']];
  const fare = ar ? ['4–6 حصص مباشرة شهريًا · 45 / 75 / 90 دقيقة حسب العمر', 'مجموعات صغيرة 8–16 · تقرير للأهل بعد كل حصة · شهادة لكل مستوى', 'حقيبة SkyLab المنزلية مشمولة مع التزام 3 أشهر · خصم 10٪ للطفل الثاني', 'مدى · بطاقات · STC Pay · تمارا — فاتورة إلكترونية · أوقف نهاية أي شهر'] : ['4–6 live sessions a month · 45 / 75 / 90 minutes by age', 'Small groups 8–16 · a parent report after every class · a certificate per level', 'Home SkyLab Kit included with a 3-month commitment · 10% off the second child', 'Mada · cards · STC Pay · Tamara — e-invoice · pause at the end of any month'];
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqLd) }} />
      <section className="hero" id="top"><KiteFlight /><div className="wrap">
        <div className="copy">
          <div className="kicker">FUNADEMY · STEM ACADEMY · RIYADH · <span className="ar-body">{ar ? 'من 4 إلى 18' : 'AGES 4–18'}</span></div>
          <h1>{ar ? <>لا نعلّم أطفالنا عن الهندسة&nbsp;—<br /><span className="hl">بل نصنع منهم مهندسين.</span></> : <>We don&apos;t teach kids about engineering&nbsp;—<br /><span className="hl">we make them engineers.</span></>}</h1>
          <p className="lede">{ar ? 'أكاديمية STEM كاملة: هندسة وبرمجة حضوريًا في الرياض، ورياضيات وعلوم مباشرة أونلاين — من أول مكعّب إلى أول سطر برمجة، ومن أول تجربة إلى أول معادلة.' : 'A complete STEM academy: engineering and coding in person in Riyadh, math and science live online — from the first brick to the first line of code, from the first experiment to the first equation.'}</p>
          <div className="stem">{PILLARS.map(p => <span className="k" key={p.k}><b className={p.k} style={{ background: `var(--${p.k})` }}>{p.k}</b>{ar ? p.ar : p.en}</span>)}</div>
          <div className="ctas"><a className="btn btn-gold" href={href(locale, '/book')}>{t.hero.cta}</a><a className="btn btn-line" href="#map">{ar ? 'خريطة STEM حسب العمر' : 'STEM map by age'}</a></div>
          <div className="trust">{(ar ? ['أكاديمية مرخّصة', 'شهادة لكل مستوى', 'مجموعات 8–16', 'تقرير للأهل بعد كل حصة'] : ['Licensed academy', 'A certificate per level', 'Groups of 8–16', 'Parent report after every class']).map(x => <span key={x}>{x}</span>)}</div>
          <div className="facts"><div className="fact"><b>{programs.length}</b>{ar ? 'برنامجًا ومستوى' : 'programs & levels'}</div><div className="fact"><b>8–16</b>{ar ? 'طالبًا في المجموعة' : 'per group'}</div><div className="fact"><b>1,380</b>{ar ? 'ريال شهريًا · الأولى مجانية' : 'SAR / month · first free'}</div></div>
        </div>
        <div className="playwrap"><div className="playhead"><b>{ar ? 'جرّب STEM الآن — أربع تجارب حيّة' : 'Try STEM now — four live experiments'}</b><span className="live">LIVE DEMO</span></div><Playground locale={locale} /></div>
      </div></section>

      <div className="proof"><div className="wrap">
        <div><b>4–18</b><span>{ar ? 'سنة — مسار واحد' : 'years — one path'}</span></div>
        <div><b>{programs.length}</b><span>{ar ? 'برنامجًا ومستوى' : 'programs & levels'}</span></div>
        <div><b>50</b><span>{ar ? 'مهمة SkyLab في السنة الأولى' : 'SkyLab missions in Year A'}</span></div>
        <div><b>8–16</b><span>{ar ? 'طالبًا في المجموعة' : 'students per group'}</span></div>
        <div><b>1</b><span>{ar ? 'حصة تجريبية مجانية' : 'free trial class'}</span></div>
      </div></div>
      <section className="blk tex-T" id="board"><div className="wrap">
        <div className="sec-head"><span className="n">01 · LIVE LABS</span><h2>{ar ? 'حصص هذا الأسبوع — حضورية في الرياض، وSkyLab أونلاين' : "This week's labs — in person in Riyadh, SkyLab online"}</h2><div className="gstripe" /></div>
        <Departures rows={rows} locale={locale} empty={t.ticker.empty} />
      </div></section>

      <section className="blk tex-M" id="map"><div className="wrap">
        <div className="sec-head"><span className="n">02 · STEM MAP</span><h2>{ar ? 'خريطة STEM حسب عمر طفلك' : "The STEM map by your child's age"}</h2><span className="sub">{ar ? 'أربعة خطوط، محطاتها البرامج — حرّك المؤشر' : 'Four lines, the programs are the stations — move the cursor'}</span><div className="gstripe" /></div>
        <StemMap programs={programs} locale={locale} />
      </div></section>

      <section className="blk" id="photos"><div className="wrap">
        <div className="sec-head"><span className="n">IN THE CLASSROOM</span><h2>{ar ? 'أطفال يبنون، يبرمجون، يجرّبون، ويقيسون' : 'Children building, coding, experimenting, measuring'}</h2><span className="sub">{ar ? 'مشاهد من حصص FunAdemy — صور حقيقية من الفصول تُنشر بموافقة الأهالي' : "Scenes from FunAdemy classes — real class photos published with parents' consent"}</span><div className="gstripe" /></div>
        <div className="photos">{SCENES.map(sc => <div className="photo" key={sc.f}><img src={`/scenes/${sc.f}.svg`} alt="" loading="lazy" /><div className="cap"><small>{sc.tag} · {ar ? sc.whereAr : sc.whereEn}</small>{ar ? sc.ar : sc.en}</div></div>)}</div>
      </div></section>

      <section className="blk tex-S" id="labs"><div className="wrap">
        <div className="sec-head"><span className="n">03 · S · T · E · M</span><h2>{ar ? 'أربعة أركان، أكاديمية واحدة' : 'Four pillars, one academy'}</h2><div className="gstripe" /></div>
        <div className="four">{PILLARS.map(p => <div className={'pillar ' + p.k} key={p.k}><div className="ic">{ICONS[p.k]}</div><div className="L">{p.k}</div><h3>{ar ? p.ar : p.en}</h3><div className="ar-name">{p.progs.map(x => x.replace(/ \d.*$/, '')).filter((v, i, a) => a.indexOf(v) === i).join(' · ')}</div><ul>{(ar ? p.bul.ar : p.bul.en).map(b => <li key={b}>{b}</li>)}</ul><div className="progs">{p.progs.map(x => <span key={x}>{x}</span>)}</div><a className="try" href="#top">{ar ? p.tryAr : p.tryEn}</a></div>)}</div>
      </div></section>

      <section className="blk" id="loop"><div className="wrap">
        <div className="sec-head"><span className="n">04 · THE FUNADEMY LOOP</span><h2>{ar ? 'كل حصة: يبني، يختبر، يحسّن، يعرض' : 'Every session: build, test, improve, present'}</h2><div className="gstripe" /></div>
        <LoopRing steps={loop} />
      </div></section>

      <section className="blk" id="fare"><div className="wrap">
        <div className="sec-head"><span className="n">05 · ONE PRICE</span><h2>{ar ? 'سعر واحد، وحصة أولى مجانية' : 'One price, and a free first class'}</h2><div className="gstripe" /></div>
        <div className="ticket">
          <div className="left"><div className="tear">FUNADEMY · MONTHLY {ar && <span className="ar-body">· الاشتراك الشهري</span>}</div><div className="fare">1,380 <small>{ar ? 'ريال / طفل / برنامج' : 'SAR / child / program'}</small></div><ul>{fare.map(x => <li key={x}>{x}</li>)}</ul><a href={href(locale, '/pricing')} className="tear" style={{ textDecoration: 'underline' }}>{ar ? 'تفاصيل الأسعار' : 'PRICING DETAILS'}</a></div>
          <div className="right"><div className="tear">✂ {ar ? <span className="ar-body">الحصة الأولى</span> : 'FIRST CLASS'}</div><h3>{t.price.free}</h3><p style={{ margin: 0, color: '#3A2E00' }}>{t.price.tryP}</p><QuickBook locale={locale} programs={programs} /></div>
        </div>
      </div></section>

      <section className="blk" id="countdown"><div className="wrap">
        <div className="sec-head"><span className="n">06 · SKYLAB MISSION 1</span><h2>{ar ? 'مهمة SkyLab الأولى تنطلق خلال' : 'SkyLab Mission 1 launches in'}</h2><div className="gstripe" /></div>
        <p className="note">{t.skylab.pilotP}</p>
        <Countdown target={pilot || '2026-10-04T17:00:00+03:00'} labels={ar ? ['يومًا', 'ساعة', 'دقيقة', 'ثانية'] : ['DAYS', 'HOURS', 'MIN', 'SEC']} />
        <a className="btn btn-gold" href={href(locale, '/book?program=skylab-lift-off')}>{t.skylab.pilotCta}</a>
      </div></section>

      <section className="blk" id="route"><div className="wrap">
        <div className="sec-head"><span className="n">07 · NATIONAL CAMPAIGN</span><h2>{t.campaign.h}</h2><div className="gstripe" /></div>
        <div className="route">
          <svg viewBox="0 0 1200 250" aria-hidden="true"><path d="M80 190 Q 300 40 460 150 T 820 120 T 1120 70" fill="none" stroke="#A78BFA" strokeWidth="3" strokeDasharray="4 12" strokeLinecap="round" />
            <g fontFamily="Baloo Bhaijaan 2, IBM Plex Sans Arabic, sans-serif" fontSize="22" fontWeight="800" textAnchor="middle">
              {[[80, 190, '#1C54CB', '#1C54CB'], [460, 150, '#6D28D9', '#6D28D9'], [820, 120, '#FFCA17', '#B8930A']].map(([x, y, c, tc], i) => <g key={i}><circle cx={x} cy={y} r="22" fill={c as string} /><text x={x} y={Number(y) + 48} fill={tc as string}>{t.campaign.phases[i]}</text></g>)}
              <circle cx="1120" cy="70" r="26" fill="#0E6B3A" stroke="#fff" strokeWidth="3" /><text x="1120" y="122" fill="#0E6B3A">{t.campaign.phases[3]}</text>
            </g></svg>
          <p className="note">{t.campaign.p}</p>
          <div className="mw"><div className="mono" style={{ color: '#0E6B3A' }}>MINI WATAN · 23 SEPTEMBER 2027</div><h3 style={{ fontSize: '1.35rem', margin: '6px 0' }}>{t.campaign.mwH}</h3><p className="note" style={{ margin: 0 }}>{t.campaign.mwP}</p><p style={{ margin: '12px 0 0' }}><a className="btn btn-line" href={href(locale, '/schools')} style={{ padding: '10px 18px', fontSize: '.95rem' }}>{t.campaign.mwCta}</a></p></div>
        </div>
      </div></section>

      {quotes.length > 0 && <section className="blk"><div className="wrap"><div className="sec-head"><span className="n">PARENTS</span><h2>{t.testi.h}</h2><div className="gstripe" /></div><div className="four">{quotes.map(q => <div className="pillar" key={q.id} style={{ minHeight: 0 }}><p>{ar ? q.quoteAr : q.quoteEn}</p><div className="mono" style={{ color: 'var(--purple)' }}>{ar ? q.whoAr : q.whoEn}</div></div>)}</div></div></section>}

      <section className="blk" id="tower"><div className="wrap">
        <div className="sec-head"><span className="n">08 · QUESTIONS & CONTACT</span><h2>{ar ? 'أسئلة يسألها الأهالي — وتواصل' : 'Questions parents ask — and contact'}</h2><div className="gstripe" /></div>
        <div className="tower">
          <div className="paper">{faqs.map((f, i) => <details key={f.id} open={i === 0}><summary>{ar ? f.qAr : f.qEn}</summary><p>{ar ? f.aAr : f.aEn}</p></details>)}</div>
          <div className="pillar dark" style={{ minHeight: 0 }}><div className="mono" style={{ color: '#DCE3FF' }}>CONTACT · <span className="ar-body">{ar ? t.contact.p : t.contact.p.toUpperCase()}</span></div><h3 style={{ margin: '8px 0' }}>{t.contact.h}</h3><p><a href={WA()} className="btn btn-gold" style={{ width: '100%', marginBottom: 8 }}>{t.contact.wa}</a><a href="mailto:admin@funademy.io" className="btn btn-line" style={{ width: '100%' }}>admin@funademy.io</a></p><p className="note" style={{ margin: 0 }}>Instagram · YouTube · LinkedIn: @funademy</p></div>
        </div>
      </div></section>
    </>
  );
}
