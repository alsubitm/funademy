import type { Metadata } from 'next';
import { DICT, WA, type Locale } from '@/lib/i18n';
export function generateMetadata({ params }: { params: { locale: Locale } }): Metadata { const t = DICT[params.locale]; return { title: t.contact.h, description: t.contact.p }; }
export default function Contact({ params }: { params: { locale: Locale } }) {
  const t = DICT[params.locale];
  return (
    <>
      <div className="wrap pagehead pattern"><div className="kicker">CONTROL TOWER</div><h1>{t.contact.h}</h1><p className="lede">{t.contact.p}</p></div>
      <section className="pg"><div className="wrap grid g3">
        <div className="engine"><div className="part">WHATSAPP</div><h3 style={{ fontSize: '1.2rem', margin: '6px 0' }}>{t.contact.wa}</h3><p><a className="btn btn-gold" href={WA()} target="_blank" rel="noopener" style={{ width: '100%' }}>{t.contact.wa}</a></p><p className="note" style={{ margin: 0 }}>{t.contact.waP}</p></div>
        <div className="engine"><div className="part">EMAIL</div><h3 style={{ fontSize: '1.2rem', margin: '6px 0' }}>{t.contact.mail}</h3><p><a className="btn btn-line" href="mailto:admin@funademy.io" style={{ width: '100%' }}>admin@funademy.io</a></p><p className="note" style={{ margin: 0 }}>{t.contact.mailP}</p></div>
        <div className="engine"><div className="part">FOLLOW</div><h3 style={{ fontSize: '1.2rem', margin: '6px 0' }}>{t.contact.follow}</h3><p>Instagram · YouTube · LinkedIn: <b>@funademy</b></p><p className="note" style={{ margin: 0 }}>{t.contact.followP}</p></div>
      </div></section>
    </>
  );
}
