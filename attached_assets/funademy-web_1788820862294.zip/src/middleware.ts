import { NextResponse, type NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (pathname.startsWith('/api') || pathname.startsWith('/_next') || pathname === '/favicon.ico' || pathname === '/robots.txt' || pathname === '/sitemap.xml' || /\.[a-z0-9]+$/i.test(pathname)) return;
  if (pathname === '/en' || pathname.startsWith('/en/')) return; // English lives at /en
  if (pathname === '/ar' || pathname.startsWith('/ar/')) { // canonical Arabic is the root
    const url = req.nextUrl.clone(); url.pathname = pathname.replace(/^\/ar/, '') || '/'; return NextResponse.redirect(url, 308);
  }
  const url = req.nextUrl.clone(); url.pathname = `/ar${pathname}`;
  return NextResponse.rewrite(url);
}
export const config = { matcher: ['/((?!_next/static|_next/image).*)'] };
