'use client';
import { useState } from 'react';
import type { Program } from '@/db/schema';
import { DICT, WA, type Locale } from '@/lib/i18n';
/** The tear-off stub on the fare ticket: name + phone + program → same bookings API. */
export function QuickBook({ locale, programs }: { locale: Locale; programs: Program[] }) {
  const t = DICT[locale]; const ar = locale === 'ar';
  const [state, setState] = useState<'idle' | 'sending' | 'ok' | 'err'>('idle');
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setState('sending');
    const fd = new FormData(e.currentTarget);
    const r = await fetch('/api/bookings', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ parentName: fd.get('parentName'), phone: fd.get('phone'), childAge: fd.get('childAge'), programSlug: fd.get('programSlug'), preferredTime: '', city: ar ? 'الرياض' : 'Riyadh', notes: 'fare-ticket', locale }) }).catch(() => null);
    setState(r && r.ok ? 'ok' : 'err');
  }
  if (state === 'ok') return <div style={{ fontWeight: 700, color: '#3A2E00' }}>{t.book.ok}</div>;
  return (
    <form onSubmit={submit} style={{ display: 'grid', gap: 8, marginTop: 6 }}>
      <input name="parentName" required minLength={2} placeholder={t.book.name} style={{ padding: 12, borderRadius: 10, border: '1.5px solid #B8930A', font: 'inherit' }} />
      <input name="phone" required type="tel" inputMode="tel" pattern="[+0-9 ()-]{9,20}" placeholder={t.book.phoneHint} style={{ padding: 12, borderRadius: 10, border: '1.5px solid #B8930A', font: 'inherit', direction: 'ltr' }} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8 }}>
        <select name="childAge" defaultValue="8" aria-label={t.book.age} style={{ padding: 12, borderRadius: 10, border: '1.5px solid #B8930A', font: 'inherit' }}>{Array.from({ length: 15 }, (_, i) => i + 4).map(a => <option key={a} value={a}>{a}</option>)}</select>
        <select name="programSlug" aria-label={t.book.program} style={{ padding: 12, borderRadius: 10, border: '1.5px solid #B8930A', font: 'inherit' }}>{programs.map(p => <option key={p.slug} value={p.slug}>{p.name}</option>)}</select>
      </div>
      <button className="btn btn-ink" type="submit" disabled={state === 'sending'}>{state === 'sending' ? t.book.sending : (ar ? 'احجز تذكرتي المجانية' : 'Book my free ticket')}</button>
      {state === 'err' && <div style={{ color: '#7A1C1C', fontWeight: 700, fontSize: '.9rem' }}>{t.book.err}</div>}
      <a href={WA()} className="tear" style={{ textDecoration: 'underline' }}>WHATSAPP · {ar ? 'أو عبر واتساب' : 'OR VIA WHATSAPP'}</a>
    </form>
  );
}
