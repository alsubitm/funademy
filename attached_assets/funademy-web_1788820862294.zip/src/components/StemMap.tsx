'use client';
import { useMemo, useState } from 'react';
import type { Program } from '@/db/schema';
import { StemCard } from './StemCard';
import type { Locale } from '@/lib/i18n';

const LINES: [string, number, string][] = [['S', 55, '#7FB3FF'], ['T', 155, '#C4B5FD'], ['E', 255, '#FFCA17'], ['M', 355, '#FFFFFF']];
const X = (a: number) => 60 + (a - 4) / 14 * 1080;

export function StemMap({ programs, locale, initial = 8 }: { programs: Program[]; locale: Locale; initial?: number }) {
  const ar = locale === 'ar';
  const [age, setAge] = useState(initial);
  const pills = useMemo(() => {
    const lanes: Record<string, number[]> = { S: [], T: [], E: [], M: [] }; const out: JSX.Element[] = [];
    programs.forEach(p => p.stem.split(',').forEach(k => {
      const line = LINES.find(l => l[0] === k); if (!line) return;
      const [, y, c] = line; const x1 = X(p.ageMin) - 18, x2 = X(p.ageMax) + 18; const on = age >= p.ageMin && age <= p.ageMax;
      let li = 0; while (lanes[k][li] !== undefined && lanes[k][li] > x1 - 6) li++; lanes[k][li] = x2;
      const yy = y + ([-16, 16, -38, 38][li] || 0); const label = p.name.replace('SkyLab ', '').toUpperCase();
      out.push(<g key={p.slug + k} opacity={on ? 1 : .5}><rect x={x1} y={yy - 10} width={x2 - x1} height={20} rx={10} fill={on ? c : 'rgba(7,31,77,.55)'} stroke={c} strokeWidth={on ? 0 : 1.5} /><text x={(x1 + x2) / 2} y={yy + 4} textAnchor="middle" fontFamily="IBM Plex Mono, monospace" fontSize="11" fontWeight="600" fill={on ? '#101A38' : '#fff'}>{label}</text></g>);
    }));
    return out;
  }, [programs, age]);
  const match = programs.filter(p => age >= p.ageMin && age <= p.ageMax);
  const path = (track: 'skylab' | 'engineering') => {
    const st = programs.filter(p => p.track === track && p.ageMax >= age).sort((a, b) => a.ageMin - b.ageMin);
    const pts: string[] = [];
    st.forEach(p => { const line = LINES.find(l => l[0] === p.stem.split(',')[0]); if (!line) return; const y = line[1]; pts.push(`${Math.max(X(age), X(p.ageMin))},${y}`); pts.push(`${X(p.ageMax)},${y}`); });
    return pts.length ? <polyline points={pts.join(' ')} fill="none" stroke="#FFCA17" strokeWidth={2.5} strokeDasharray="6 6" opacity={.9} /> : null;
  };
  const legend = ar ? [['S', 'العلوم', '#7FB3FF'], ['T', 'التقنية', '#C4B5FD'], ['E', 'الهندسة', '#FFCA17'], ['M', 'الرياضيات', '#fff']] : [['S', 'Science', '#7FB3FF'], ['T', 'Technology', '#C4B5FD'], ['E', 'Engineering', '#FFCA17'], ['M', 'Math', '#fff']];
  return (
    <>
      <div className="map">
        <div className="ctl"><span className="mono" style={{ color: '#AEB9DD' }}>AGE</span><span className="big" aria-live="polite">{String(age).padStart(2, '0')}</span><input type="range" min={4} max={18} value={age} onChange={e => setAge(Number(e.target.value))} aria-label={ar ? 'عمر الطفل' : "Child's age"} /><span className="note">{ar ? 'اسحب لتغيير العمر' : 'drag to change the age'}</span></div>
        <div className="legend">{legend.map(([k, n, c]) => <span key={k}><i style={{ background: c }} />{k} {n}</span>)}<span><i style={{ background: 'transparent', border: '2px dashed #FFCA17' }} />{ar ? 'مسار طفلك حتى 18' : "Your child's path to 18"}</span></div>
        <div className="svgwrap"><svg viewBox="0 0 1200 400" aria-hidden="true">
          <g fontFamily="IBM Plex Mono, monospace" fontSize="12" fill="#DCE3FF">{Array.from({ length: 15 }, (_, i) => i + 4).map(a => <g key={a}><text x={X(a)} y={392} textAnchor="middle">{a}</text><line x1={X(a)} y1={20} x2={X(a)} y2={375} stroke="rgba(255,255,255,.07)" /></g>)}</g>
          {LINES.map(([k, y, c]) => <g key={k}><line x1={40} y1={y} x2={1160} y2={y} stroke={c} strokeWidth={3} opacity={.35} /><text x={18} y={y + 5} fontFamily="Baloo Bhaijaan 2, sans-serif" fontSize="20" fontWeight="800" fill={c} textAnchor="middle">{k}</text></g>)}
          {pills}{path('engineering')}{path('skylab')}
          <line x1={X(age)} y1={14} x2={X(age)} y2={378} stroke="#FFCA17" strokeWidth={3} /><circle cx={X(age)} cy={14} r={6} fill="#FFCA17" />
        </svg></div>
      </div>
      <div className="cards">{match.map(p => <StemCard key={p.slug} p={p} locale={locale} />)}</div>
    </>
  );
}
