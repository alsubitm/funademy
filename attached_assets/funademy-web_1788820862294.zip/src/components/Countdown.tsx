'use client';
import { useEffect, useState } from 'react';
export function Countdown({ target, labels }: { target: string; labels: string[] }) {
  const [v, setV] = useState(['--', '--', '--', '--']);
  useEffect(() => {
    const T0 = new Date(target).getTime();
    const tick = () => { let d = Math.max(0, T0 - Date.now()); const D = Math.floor(d / 864e5); d -= D * 864e5; const H = Math.floor(d / 36e5); d -= H * 36e5; const M = Math.floor(d / 6e4); d -= M * 6e4; const S = Math.floor(d / 1e3); setV([D, H, M, S].map(x => String(x).padStart(2, '0'))); };
    tick(); const id = setInterval(tick, 1000); return () => clearInterval(id);
  }, [target]);
  return <div className="cd">{v.map((x, i) => <div key={i}><b>{x}</b><span>{labels[i]}</span></div>)}</div>;
}
