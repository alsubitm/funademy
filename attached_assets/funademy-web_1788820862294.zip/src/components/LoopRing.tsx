import { KiteSvg } from './KiteCap';
export function LoopRing({ steps }: { steps: string[][] }) {
  const cols = ['#0B3D91', '#6D28D9', '#1C54CB', '#FFCA17'];
  const pos = [[210, 60], [360, 210], [210, 360], [60, 210]];
  return (
    <div className="ring">
      <svg viewBox="0 0 420 420" aria-hidden="true">
        <defs><linearGradient id="rg" x1="0" x2="1"><stop offset="0" stopColor="#0B3D91" /><stop offset="1" stopColor="#6D28D9" /></linearGradient></defs>
        <circle cx="210" cy="210" r="150" fill="none" stroke="url(#rg)" strokeWidth="10" strokeDasharray="8 10" strokeLinecap="round" />
        <foreignObject x="150" y="140" width="120" height="150"><div style={{ width: 120, height: 150 }}><KiteSvg color="#F5F7FF" /></div></foreignObject>
        {pos.map(([x, y], i) => <g key={i}><circle cx={x} cy={y} r="34" fill={cols[i]} /><text x={x} y={y + 8} textAnchor="middle" fontFamily="Baloo Bhaijaan 2, IBM Plex Sans Arabic, sans-serif" fontWeight="800" fontSize="22" fill={i === 3 ? '#101A38' : '#fff'}>{i + 1}</text></g>)}
      </svg>
      <div className="steps">{steps.map(([h, p], i) => <div className="step" key={h}><div className="num">{i + 1}</div><div><b>{h}</b><span>{p}</span></div></div>)}</div>
    </div>
  );
}
