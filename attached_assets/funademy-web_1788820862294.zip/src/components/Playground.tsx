'use client';
import { useEffect, useMemo, useState } from 'react';
import type { Locale } from '@/lib/i18n';

const gearPath = (r: number, teeth: number) => { let d = ''; const n = teeth * 2; for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2; const rr = i % 2 ? r : r * .8; d += (i ? 'L' : 'M') + (Math.cos(a) * rr).toFixed(1) + ' ' + (Math.sin(a) * rr).toFixed(1) + ' '; } return d + 'Z'; };

function Density({ ar }: { ar: boolean }) {
  const [g, setG] = useState(0);
  const rho = 1 + g * 0.0007; const floats = rho >= 1.03;
  const salt = useMemo(() => Array.from({ length: Math.round(g / 6) }, (_, i) => ({ x: 62 + (i * 13) % 80, y: 45 + (i * 29) % 60 })), [g]);
  return (
    <div className="lab S"><span className="try">{ar ? 'جرّبها' : 'try it'}</span>
      <div className="h"><b>{ar ? 'يغرق أم يطفو؟' : 'Sink or float?'}</b><span className="tagp">S · SKYLAB · GLIDE</span></div>
      <div className="stage"><svg viewBox="0 0 200 120" width="100%" style={{ maxWidth: 220 }}><rect x="55" y="12" width="90" height="100" rx="10" fill="rgba(255,255,255,.08)" stroke="#7FB3FF" strokeWidth="2" /><rect x="58" y="40" width="84" height="69" rx="8" fill="rgba(127,179,255,.35)" /><ellipse cx="100" cy={floats ? 52 - (rho - 1.03) * 400 : 92} rx="14" ry="18" fill="#F7EFDD" stroke="#101A38" strokeWidth="2" /><g fill="#fff">{salt.map((s, i) => <circle key={i} cx={s.x} cy={s.y} r="1.4" opacity=".8" />)}</g></svg></div>
      <input type="range" min={0} max={100} value={g} onChange={e => setG(Number(e.target.value))} aria-label="salt" />
      <div className="out">{ar ? 'ملح' : 'salt'} {g} g · ρ = {rho.toFixed(3)} g/mL · {floats ? (ar ? 'يطفو ↑' : 'floats ↑') : (ar ? 'يغرق ↓' : 'sinks ↓')}</div><a className="more" href="#map">SKYLAB GLIDE · {ar ? 'الكثافة' : 'DENSITY'}</a>
    </div>
  );
}

function CodeKite({ ar }: { ar: boolean }) {
  const [seq, setSeq] = useState<string[]>([]);
  const [pos, setPos] = useState({ x: 0, y: 3, d: 0 });
  const [msg, setMsg] = useState('');
  const goal = { x: 3, y: 1 };
  const names: Record<string, string> = { F: 'forward', R: 'turn ↻', L: 'turn ↺' };
  function run() {
    let p = { x: 0, y: 3, d: 0 }; setPos(p); setMsg(''); let i = 0;
    const step = () => {
      if (i >= seq.length) { const ok = p.x === goal.x && p.y === goal.y; setMsg(ok ? (ar ? '✓ وصلت الطيارة إلى النجمة!' : '✓ The kite reached the star!') : (ar ? '✗ لم تصل — جرّب ترتيبًا آخر' : '✗ Not there yet — try another order')); return; }
      const c = seq[i++];
      if (c === 'R') p = { ...p, d: (p.d + 1) % 4 }; else if (c === 'L') p = { ...p, d: (p.d + 3) % 4 };
      else { const dx = [0, 1, 0, -1][p.d], dy = [-1, 0, 1, 0][p.d]; p = { ...p, x: Math.max(0, Math.min(3, p.x + dx)), y: Math.max(0, Math.min(3, p.y + dy)) }; }
      setPos(p); setTimeout(step, 380);
    };
    step();
  }
  return (
    <div className="lab T"><span className="try">{ar ? 'جرّبها' : 'try it'}</span>
      <div className="h"><b>{ar ? 'برمج الطيارة' : 'Code the kite'}</b><span className="tagp">T · ALGOPLAY</span></div>
      <div className="stage"><svg viewBox="0 0 160 120" width="100%" style={{ maxWidth: 200 }}>
        {Array.from({ length: 16 }, (_, i) => <rect key={i} x={(i % 4) * 40 + 2} y={Math.floor(i / 4) * 30 + 2} width="36" height="26" rx="4" fill="rgba(255,255,255,.05)" stroke="rgba(255,255,255,.15)" />)}
        <path d={`M${goal.x * 40 + 20} ${goal.y * 30 + 5} l3 7 7 3 -7 3 -3 7 -3 -7 -7 -3 7 -3z`} fill="#FFCA17" />
        <g transform={`translate(${pos.x * 40 + 20} ${pos.y * 30 + 15}) rotate(${pos.d * 90})`}><polygon points="0,-11 9,0 0,11 -9,0" fill="#FFCA17" stroke="#F5F7FF" strokeWidth="2" /><circle r="2.5" fill="#1C54CB" /></g>
      </svg></div>
      <div className="seq">▸ {msg || (seq.map(c => names[c]).join(' → ') || '…')}</div>
      <div className="codebtns">
        {(['F', 'R', 'L'] as const).map(c => <button key={c} onClick={() => seq.length < 8 && setSeq([...seq, c])}>{c === 'F' ? 'forward ↑' : c === 'R' ? 'turn ↻' : 'turn ↺'}</button>)}
        <button className="run" onClick={run}>RUN ▶</button><button onClick={() => { setSeq([]); setPos({ x: 0, y: 3, d: 0 }); setMsg(''); }}>clear</button>
      </div>
    </div>
  );
}

function Gears({ ar }: { ar: boolean }) {
  const [a, setA] = useState(0);
  return (
    <div className="lab E"><span className="try">{ar ? 'جرّبها' : 'try it'}</span>
      <div className="h"><b>{ar ? 'نسبة التروس' : 'Gear ratio'}</b><span className="tagp">E · BRICKS CHALLENGE</span></div>
      <div className="stage"><svg viewBox="0 0 220 120" width="100%" style={{ maxWidth: 230 }}>
        <g transform={`translate(70 60) rotate(${a})`}><path d={gearPath(46, 16)} fill="#FFCA17" stroke="#101A38" strokeWidth="2" /><circle r="8" fill="#1C54CB" stroke="#101A38" strokeWidth="2" /><line x1="0" y1="-30" x2="0" y2="-8" stroke="#101A38" strokeWidth="3" /></g>
        <g transform={`translate(150 60) rotate(${-a * 2 + 11})`}><path d={gearPath(24, 8)} fill="#F2CD7E" stroke="#101A38" strokeWidth="2" /><circle r="6" fill="#1C54CB" stroke="#101A38" strokeWidth="2" /><line x1="0" y1="-16" x2="0" y2="-6" stroke="#101A38" strokeWidth="3" /></g>
      </svg></div>
      <input type="range" min={0} max={360} value={a} onChange={e => setA(Number(e.target.value))} aria-label="turn the big gear" />
      <div className="out">16 : 8 · {ar ? 'الصغير يدور ×2 وبالعكس' : 'small gear turns ×2, opposite way'} · {a}° → {a * 2}°</div><a className="more" href="#map">BRICKS CHALLENGE · {ar ? 'التروس' : 'GEARS'}</a>
    </div>
  );
}

function Shadow({ ar }: { ar: boolean }) {
  const [ang, setAng] = useState(45);
  const h = 50; const rad = ang * Math.PI / 180; const sh = Math.min(105, h / Math.tan(rad)); const sx = 120 + Math.cos(rad) * 80, sy = 100 - Math.sin(rad) * 80;
  return (
    <div className="lab M"><span className="try">{ar ? 'جرّبها' : 'try it'}</span>
      <div className="h"><b>{ar ? 'ساعة الظل' : 'Shadow clock'}</b><span className="tagp">M · SKYLAB · LIFT-OFF</span></div>
      <div className="stage"><svg viewBox="0 0 220 120" width="100%" style={{ maxWidth: 230 }}><line x1="10" y1="100" x2="210" y2="100" stroke="#F2CD7E" strokeWidth="2" /><line x1="120" y1="100" x2={120 - sh} y2="100" stroke="#0B2263" strokeWidth="8" strokeLinecap="round" /><line x1="120" y1="100" x2="120" y2="50" stroke="#FFCA17" strokeWidth="5" strokeLinecap="round" /><circle cx={sx} cy={sy} r="10" fill="#FFCA17" /><line x1={sx} y1={sy} x2="120" y2="50" stroke="#FFCA17" strokeWidth="1.5" strokeDasharray="4 4" /></svg></div>
      <input type="range" min={15} max={75} value={ang} onChange={e => setAng(Number(e.target.value))} aria-label="sun angle" />
      <div className="out">{ar ? 'زاوية الشمس' : 'sun'} {ang}° · {ar ? 'الظل' : 'shadow'} = 50 ÷ tan({ang}°) = {(50 / Math.tan(rad)).toFixed(0)} cm</div><a className="more" href="#map">SKYLAB LIFT-OFF · {ar ? 'ساعة الظل' : 'SHADOW CLOCK'}</a>
    </div>
  );
}

export function Playground({ locale }: { locale: Locale }) {
  const ar = locale === 'ar';
  useEffect(() => { /* hydration marker */ }, []);
  return (
    <div className="play" aria-label="STEM playground">
      <Density ar={ar} /><CodeKite ar={ar} /><Gears ar={ar} /><Shadow ar={ar} />
    </div>
  );
}
