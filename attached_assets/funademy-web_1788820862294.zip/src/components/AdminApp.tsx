'use client';
import { useEffect, useState, useCallback } from 'react';

type Booking = { id: number; createdAt: string; status: string; parentName: string; phone: string; childAge: number; programSlug: string; preferredTime: string; city: string; notes: string; locale: string; adminNote: string };
type Slot = { id: number; programSlug: string; weekday: number; time: string; capacity: number; seatsLeft: number; formatAr: string; formatEn: string; isOpen: boolean };
type Testi = { id: number; quoteAr: string; quoteEn: string; whoAr: string; whoEn: string; approved: boolean; sortOrder: number };
type Faq = { id: number; qAr: string; qEn: string; aAr: string; aEn: string; page: string; sortOrder: number; active: boolean };
type Program = { slug: string; name: string };
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const STATUS = ['new', 'contacted', 'trial_booked', 'enrolled', 'closed'];

async function api(path: string, init?: RequestInit) {
  const r = await fetch(path, { ...init, headers: { 'content-type': 'application/json', ...(init?.headers || {}) } });
  if (r.status === 401) throw new Error('unauthorized');
  return r.json();
}

export function AdminApp() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [pw, setPw] = useState('');
  const [tab, setTab] = useState<'bookings' | 'slots' | 'testimonials' | 'faqs' | 'stats'>('bookings');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [testis, setTestis] = useState<Testi[]>([]);
  const [faqs, setFaqs] = useState<Faq[]>([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [stats, setStats] = useState<{ byStatus: { status: string; n: number }[]; byProgram: { program: string; n: number }[]; events30d: { name: string; n: number }[] } | null>(null);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    try {
      const [b, s, t, f, p, st] = await Promise.all([api('/api/admin/bookings'), api('/api/admin/slots'), api('/api/admin/testimonials'), api('/api/admin/faqs'), api('/api/programs'), api('/api/admin/stats')]);
      setBookings(b); setSlots(s); setTestis(t); setFaqs(f); setPrograms(p); setStats(st); setAuthed(true);
    } catch { setAuthed(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  async function login(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: pw }) });
    if (r.ok) load(); else setErr('Wrong password');
  }
  async function logout() { await fetch('/api/admin/logout', { method: 'POST' }); setAuthed(false); }
  const patch = (path: string, body: unknown) => api(path, { method: 'PATCH', body: JSON.stringify(body) }).then(load);
  const del = (path: string) => confirm('Delete?') && api(path, { method: 'DELETE' }).then(load);

  if (authed === null) return <div className="wrap admin"><p>Loading…</p></div>;
  if (!authed) return (
    <div className="wrap admin" style={{ maxWidth: 420 }}>
      <h1 style={{ fontSize: '1.6rem' }}>FunAdemy admin</h1><div className="stripe" />
      <form onSubmit={login} className="acard"><label htmlFor="pw">Password</label><input id="pw" type="password" value={pw} onChange={e => setPw(e.target.value)} autoFocus />
        {err && <p style={{ color: '#B71C1C', fontWeight: 700 }}>{err}</p>}
        <button className="btn btn-gold" style={{ marginTop: 12 }}>Sign in</button></form>
    </div>
  );

  return (
    <div className="wrap admin">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
        <h1 style={{ fontSize: '1.6rem' }}>FunAdemy admin</h1>
        <button className="btn btn-ghost" onClick={logout} style={{ padding: '8px 16px', fontSize: '.9rem' }}>Sign out</button>
      </div>
      <div className="stripe" />
      <div className="tabs">{(['bookings', 'slots', 'testimonials', 'faqs', 'stats'] as const).map(k => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{k}</button>)}</div>

      {tab === 'bookings' && (<>
        <p><a className="btn btn-gold" href="/api/admin/bookings?format=csv" style={{ padding: '8px 16px', fontSize: '.9rem' }}>Export CSV</a> <span className="small">{bookings.length} requests</span></p>
        <div style={{ overflowX: 'auto' }}><table><thead><tr><th>#</th><th>When</th><th>Parent</th><th>Phone</th><th>Age</th><th>Program</th><th>Time</th><th>City</th><th>Notes</th><th>Status</th><th>Admin note</th></tr></thead><tbody>
          {bookings.map(b => (
            <tr key={b.id}><td>{b.id}</td><td>{new Date(b.createdAt).toLocaleString('en-GB')}</td><td>{b.parentName}</td><td dir="ltr">{b.phone}</td><td>{b.childAge}</td><td>{b.programSlug}</td><td>{b.preferredTime}</td><td>{b.city}</td><td>{b.notes}</td>
              <td><select value={b.status} onChange={e => patch(`/api/admin/bookings/${b.id}`, { status: e.target.value })}>{STATUS.map(s => <option key={s}>{s}</option>)}</select></td>
              <td><input defaultValue={b.adminNote} onBlur={e => e.target.value !== b.adminNote && patch(`/api/admin/bookings/${b.id}`, { adminNote: e.target.value })} /></td></tr>
          ))}
        </tbody></table></div>
      </>)}

      {tab === 'slots' && (<>
        <form className="acard" style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'end' }} onSubmit={async e => { e.preventDefault(); const fd = new FormData(e.currentTarget); await api('/api/admin/slots', { method: 'POST', body: JSON.stringify(Object.fromEntries(fd.entries())) }); (e.target as HTMLFormElement).reset(); load(); }}>
          <div><label>Program</label><select name="programSlug">{programs.map(p => <option key={p.slug} value={p.slug}>{p.name}</option>)}</select></div>
          <div><label>Day</label><select name="weekday">{DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}</select></div>
          <div><label>Time</label><input name="time" placeholder="17:00" pattern="\d{2}:\d{2}" required /></div>
          <div><label>Capacity</label><input name="capacity" type="number" defaultValue={12} /></div>
          <div><label>Seats left</label><input name="seatsLeft" type="number" defaultValue={12} /></div>
          <div><label>Format (AR)</label><input name="formatAr" defaultValue="أونلاين مباشر" /></div>
          <div><label>Format (EN)</label><input name="formatEn" defaultValue="live online" /></div>
          <button className="btn btn-gold" style={{ padding: '10px 18px' }}>Add slot</button>
        </form>
        <table style={{ marginTop: 14 }}><thead><tr><th>Program</th><th>Day</th><th>Time</th><th>Seats</th><th>Format</th><th>Open</th><th></th></tr></thead><tbody>
          {slots.map(s => <tr key={s.id}><td>{s.programSlug}</td><td>{DAYS[s.weekday]}</td><td>{s.time}</td>
            <td><input type="number" style={{ width: 70 }} defaultValue={s.seatsLeft} onBlur={e => Number(e.target.value) !== s.seatsLeft && patch(`/api/admin/slots/${s.id}`, { seatsLeft: Number(e.target.value) })} /> / {s.capacity}</td>
            <td>{s.formatEn}</td><td><input type="checkbox" checked={s.isOpen} onChange={e => patch(`/api/admin/slots/${s.id}`, { isOpen: e.target.checked })} /></td>
            <td><button onClick={() => del(`/api/admin/slots/${s.id}`)}>✕</button></td></tr>)}
        </tbody></table>
      </>)}

      {tab === 'testimonials' && (<>
        <p className="small">Only approved testimonials appear on the site. Approve real, consented quotes only.</p>
        <form className="acard" style={{ display: 'grid', gap: 8 }} onSubmit={async e => { e.preventDefault(); const fd = new FormData(e.currentTarget); await api('/api/admin/testimonials', { method: 'POST', body: JSON.stringify(Object.fromEntries(fd.entries())) }); (e.target as HTMLFormElement).reset(); load(); }}>
          <input name="quoteAr" placeholder="Quote (AR)" required /><input name="quoteEn" placeholder="Quote (EN)" required /><input name="whoAr" placeholder="Who (AR) — first name · الرياض" required /><input name="whoEn" placeholder="Who (EN)" required />
          <button className="btn btn-gold" style={{ padding: '10px 18px', justifySelf: 'start' }}>Add (unapproved)</button>
        </form>
        <table style={{ marginTop: 14 }}><thead><tr><th>Quote (AR)</th><th>Who</th><th>Approved</th><th></th></tr></thead><tbody>
          {testis.map(t => <tr key={t.id}><td>{t.quoteAr}</td><td>{t.whoAr}</td><td><input type="checkbox" checked={t.approved} onChange={e => patch(`/api/admin/testimonials/${t.id}`, { approved: e.target.checked })} /></td><td><button onClick={() => del(`/api/admin/testimonials/${t.id}`)}>✕</button></td></tr>)}
        </tbody></table>
      </>)}

      {tab === 'faqs' && (<>
        <form className="acard" style={{ display: 'grid', gap: 8 }} onSubmit={async e => { e.preventDefault(); const fd = new FormData(e.currentTarget); await api('/api/admin/faqs', { method: 'POST', body: JSON.stringify(Object.fromEntries(fd.entries())) }); (e.target as HTMLFormElement).reset(); load(); }}>
          <input name="qAr" placeholder="Question (AR)" required /><input name="qEn" placeholder="Question (EN)" required /><textarea name="aAr" placeholder="Answer (AR)" required /><textarea name="aEn" placeholder="Answer (EN)" required /><input name="page" defaultValue="home" />
          <button className="btn btn-gold" style={{ padding: '10px 18px', justifySelf: 'start' }}>Add FAQ</button>
        </form>
        <table style={{ marginTop: 14 }}><thead><tr><th>Question (AR)</th><th>Page</th><th>Active</th><th></th></tr></thead><tbody>
          {faqs.map(f => <tr key={f.id}><td>{f.qAr}</td><td>{f.page}</td><td><input type="checkbox" checked={f.active} onChange={e => patch(`/api/admin/faqs/${f.id}`, { active: e.target.checked })} /></td><td><button onClick={() => del(`/api/admin/faqs/${f.id}`)}>✕</button></td></tr>)}
        </tbody></table>
      </>)}

      {tab === 'stats' && stats && (
        <div className="grid g3">
          <div className="acard"><h4>Requests by status</h4>{stats.byStatus.map(s => <div className="kv" key={s.status}><span>{s.status}</span><b>{s.n}</b></div>)}</div>
          <div className="acard"><h4>Requests by program</h4>{stats.byProgram.map(s => <div className="kv" key={s.program}><span>{s.program}</span><b>{s.n}</b></div>)}</div>
          <div className="acard"><h4>Events, last 30 days</h4>{stats.events30d.map(s => <div className="kv" key={s.name}><span>{s.name}</span><b>{s.n}</b></div>)}</div>
        </div>
      )}
    </div>
  );
}
