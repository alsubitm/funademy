/** The FunAdemy mark: the kite (front) and the graduation cap (back). Official geometry, brand colours. */
export function KiteSvg({ className, color = '#F5F7FF' }: { className?: string; color?: string }) {
  return (
    <svg className={className} viewBox="0 0 340 440" style={{ color }} aria-hidden="true">
      <path d="M170 316 Q 214 356 200 392 Q 190 416 226 414" fill="none" stroke="#E5AE4A" strokeWidth="7" strokeLinecap="round" />
      <rect x="196" y="338" width="22" height="22" rx="5" fill="#22DAFF" stroke="currentColor" strokeWidth="5" transform="rotate(45 207 349)" />
      <rect x="186" y="378" width="20" height="20" rx="5" fill="#F2CD7E" stroke="currentColor" strokeWidth="5" transform="rotate(45 196 388)" />
      <path d="M240 402 l7 15 15 7 -15 7 -7 15 -7 -15 -15 -7 15 -7z" fill="#FFCA17" stroke="currentColor" strokeWidth="5" />
      <g stroke="currentColor" strokeLinejoin="round">
        <polygon points="170,36 306,176 170,316 34,176" fill="#FFCA17" strokeWidth="10" />
        <line x1="170" y1="36" x2="170" y2="316" strokeWidth="6" /><line x1="34" y1="176" x2="306" y2="176" strokeWidth="6" />
        <polygon points="170,36 306,176 170,176" fill="#FFE066" opacity=".5" stroke="none" />
        <circle cx="170" cy="176" r="16" fill="#1C54CB" strokeWidth="7" />
      </g>
    </svg>
  );
}
export function CapSvg({ className, color = '#F5F7FF' }: { className?: string; color?: string }) {
  return (
    <svg className={className} viewBox="0 0 260 240" style={{ color }} aria-hidden="true">
      <g stroke="currentColor" strokeLinejoin="round">
        <polygon points="130,44 246,104 130,164 14,104" fill="#FFCA17" strokeWidth="9" />
        <path d="M76 142 L76 188 Q130 216 184 188 L184 142" fill="#FFCA17" strokeWidth="9" />
        <circle cx="130" cy="104" r="12" fill="#1C54CB" strokeWidth="6" />
        <path d="M130 104 Q 198 118 202 168" fill="none" stroke="#E5AE4A" strokeWidth="6" strokeLinecap="round" />
        <path d="M202 168 l5.5 12 12 5.5 -12 5.5 -5.5 12 -5.5 -12 -12 -5.5 12 -5.5z" fill="#FFCA17" strokeWidth="4.5" />
      </g>
    </svg>
  );
}
/** Header/footer lockup: the kite flips into the cap on hover or keyboard focus. */
export function Lockup({ href, size = 30, color = '#0F1F4B' }: { href: string; size?: number; color?: string }) {
  return (
    <a className="logo" href={href} aria-label="FunAdemy">
      <span className="flip" style={{ width: size, height: size * 1.3 }}>
        <KiteSvg className="kite" color={color} />
        <CapSvg className="cap" color={color} />
      </span>
      <span><span className="fun">Fun</span><span className="ademy">Ademy</span></span>
    </a>
  );
}
export function Stripe({ center }: { center?: boolean }) {
  return <div className="stripe" style={center ? { marginInline: 'auto' } : undefined} />;
}
