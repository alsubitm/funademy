import type { Program } from '@/db/schema';
import { href, type Locale } from '@/lib/i18n';
const ICON: Record<string, JSX.Element> = {
  gear: <svg width="34" height="34" viewBox="0 0 24 24"><path fill="currentColor" d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.5-2-3.5-2.4 1a7.7 7.7 0 0 0-1.7-1L15 3.5h-4l-.4 2.5a7.7 7.7 0 0 0-1.7 1l-2.4-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2 1.5 2 3.5 2.4-1a7.7 7.7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.7 7.7 0 0 0 1.7-1l2.4 1 2-3.5L19.4 13zM13 15a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" /></svg>,
  code: <svg width="34" height="34" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16" /></svg>,
  flask: <svg width="34" height="34" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" d="M9 3h6M10 3v6L4.5 19a1.5 1.5 0 0 0 1.3 2.2h12.4a1.5 1.5 0 0 0 1.3-2.2L14 9V3" /><path fill="currentColor" d="M7.5 16h9l2 3.5H5.5z" opacity=".8" /></svg>,
  graph: <svg width="34" height="34" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" d="M3 20h18M4 17c3-1 5-8 8-8s4 5 8 3" /><circle cx="12" cy="9" r="1.8" fill="currentColor" /></svg>,
};
export const iconFor = (p: Program) => p.track === 'skylab' ? (p.ageMin >= 10 ? 'graph' : 'flask') : (p.stem.startsWith('T') ? 'code' : 'gear');
export function Pills({ stem }: { stem: string }) {
  const on = stem.split(',');
  return <span className="pills">{['S', 'T', 'E', 'M'].map(k => <span key={k} className={`pill ${k} ${on.includes(k) ? 'on' : ''}`}>{k}</span>)}</span>;
}
export function StemCard({ p, locale }: { p: Program; locale: Locale }) {
  const ar = locale === 'ar'; const sky = p.track === 'skylab';
  const to = href(locale, sky ? '/skylab' : `/programs/${p.slug}`);
  return (
    <div className={'card p-' + (p.stem.split(',')[0] || 'S') + (sky ? ' sky' : '')}>
      <a href={to}>
        <div className="top"><span className="field">{ar ? p.fieldAr : p.fieldEn}</span><Pills stem={p.stem} /></div>
        <h3>{p.name}</h3>
        <p className="desc">{ar ? p.oneLinerAr : p.oneLinerEn}</p>
        <div className="cells">
          <div><b>{p.ageMin}–{p.ageMax}</b><small>{ar ? 'الأعمار' : 'AGES'}</small></div>
          <div><b>{p.sessionMin}</b><small>{ar ? 'دقيقة' : 'MIN'}</small></div>
          <div><b>{p.classCap}</b><small>{ar ? 'مقعدًا' : 'SEATS'}</small></div>
          <div><b style={{ fontSize: '.9rem' }}>{(ar ? p.formatAr : p.formatEn).split(' /')[0]}</b><small>{ar ? 'الصيغة' : 'FORMAT'}</small></div>
        </div>
      </a>
      <div className="side"><div className="ico">{ICON[iconFor(p)]}</div><a className="btn btn-ink" href={href(locale, `/book?program=${p.slug}`)}>{ar ? 'احجز' : 'Book'}</a></div>
    </div>
  );
}
