import { getOpenSlots, getPrograms } from '@/lib/queries';
import { DICT, WEEKDAYS, type Locale } from '@/lib/i18n';

export async function Ticker({ locale }: { locale: Locale }) {
  const t = DICT[locale];
  const [list, progs] = await Promise.all([getOpenSlots(), getPrograms()]);
  const name = (slug: string) => progs.find(p => p.slug === slug)?.name || slug;
  const items = list.filter(s => s.seatsLeft > 0);
  if (!items.length) return <div className="ticker"><div className="wrap" style={{ padding: '12px 20px', color: '#AEB9DD' }}>{t.ticker.empty}</div></div>;
  const row = items.map(s => (
    <span className="tick" key={s.id}><span className="dot" />{t.ticker.live} · {WEEKDAYS[locale][s.weekday]} {s.time} — {name(s.programSlug)} <span className="seats">[{s.seatsLeft} {t.ticker.seats}]</span></span>
  ));
  return (
    <div className="ticker" aria-label="live classes">
      <div className="ticker-track">{row}{row.map((r, i) => <span key={'d' + i} aria-hidden="true">{r}</span>)}</div>
    </div>
  );
}
