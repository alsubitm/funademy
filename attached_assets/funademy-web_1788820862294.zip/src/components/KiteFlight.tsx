import { KiteSvg, CapSvg } from './KiteCap';
/** The kite glides along a gentle curve across the top of the hero (CSS motion path), sways as it flies, and flips into the cap under the mouse. */
export function KiteFlight() {
  return (
    <div className="flyer" aria-hidden="true">
      <svg className="trail" viewBox="0 0 1400 800" preserveAspectRatio="none"><path d="M -120 190 C 220 100, 480 240, 760 160 S 1200 100, 1500 200" /></svg>
      <div className="kf" title="FunAdemy"><KiteSvg color="#0F1F4B" /><CapSvg className="cap" color="#0F1F4B" /></div>
    </div>
  );
}
