'use client';
import { useState } from 'react';
import { usePathname } from 'next/navigation';
import { Lockup } from './KiteCap';
import { DICT, href, type Locale } from '@/lib/i18n';

export function Header({ locale }: { locale: Locale }) {
  const t = DICT[locale];
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const bare = pathname.replace(/^\/(en|ar)(?=\/|$)/, '') || '/';
  const other: Locale = locale === 'ar' ? 'en' : 'ar';
  const items: [string, string][] = [['/programs', t.nav.programs], ['/skylab', t.nav.skylab], ['/pricing', t.nav.pricing], ['/campaign', t.nav.campaign], ['/schools', t.nav.schools], ['/contact', t.nav.contact]];
  return (
    <header>
      <a className="skip" href="#main">{t.nav.skip}</a>
      <div className="wrap nav">
        <Lockup href={href(locale, '/')} />
        <nav className="menu" aria-label="main">
          {items.map(([p, label]) => <a key={p} href={href(locale, p)} style={bare.startsWith(p) ? { color: 'var(--gold)' } : undefined}>{label}</a>)}
        </nav>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <a className="lang" href={href(other, bare)} hrefLang={other} lang={other}>{t.nav.lang}</a>
          <a className="btn btn-gold" href={href(locale, '/book')} style={{ padding: '10px 16px', fontSize: '.95rem' }}>{t.nav.book}</a>
          <button className="burger" aria-label={t.nav.menu} aria-expanded={open} onClick={() => setOpen(!open)}>☰</button>
        </div>
      </div>
      <div className={'wrap drawer' + (open ? ' open' : '')}>
        {items.map(([p, label]) => <a key={p} href={href(locale, p)}>{label}</a>)}
        <a href={href(locale, '/book')} style={{ color: 'var(--gold)' }}>{t.hero.cta}</a>
      </div>
    </header>
  );
}
