import { Lockup } from './KiteCap';
import { DICT, href, WA, type Locale } from '@/lib/i18n';
export function Footer({ locale }: { locale: Locale }) {
  const t = DICT[locale];
  return (
    <footer><div className="wrap">
      <div className="fl"><Lockup href={href(locale, '/')} color="#F5F7FF" />
        <nav aria-label="footer"><a href={href(locale, '/programs')}>{t.nav.programs}</a><a href={href(locale, '/skylab')}>SkyLab</a><a href={href(locale, '/pricing')}>{t.nav.pricing}</a><a href={href(locale, '/campaign')}>{t.nav.campaign}</a><a href={href(locale, '/schools')}>{t.nav.schools}</a><a href={href(locale, '/contact')}>{t.nav.contact}</a><a href={href(locale, '/privacy')}>{t.footer.privacy}</a><a href={href(locale, '/terms')}>{t.footer.terms}</a><a href={WA()}>WhatsApp</a></nav></div>
      <div>{t.footer.about}</div>
      <div className="credit">{t.footer.credit.toUpperCase()}</div>
      <div className="credit">{t.footer.orig}</div>
    </div></footer>
  );
}
