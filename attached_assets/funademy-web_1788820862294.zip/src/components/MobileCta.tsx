import { DICT, href, WA, type Locale } from '@/lib/i18n';
export function MobileCta({ locale }: { locale: Locale }) {
  const t = DICT[locale];
  return (
    <div className="mcta" role="region" aria-label="quick actions">
      <a className="btn btn-gold" href={href(locale, '/book')}>{t.mobile.book}</a>
      <a className="btn btn-line" href={WA()} target="_blank" rel="noopener">{t.mobile.wa}</a>
    </div>
  );
}
