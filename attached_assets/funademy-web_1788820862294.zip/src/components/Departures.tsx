'use client';
import { useEffect, useRef } from 'react';
import type { Locale } from '@/lib/i18n';
export type Departure = { time: string; flight: string; gate: string; seats: number };
const CH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 :-';

function flap(el: HTMLElement, text: string, delay: number, reduced: boolean) {
  el.innerHTML = '';
  [...text].forEach((c, i) => {
    const s = document.createElement('span'); s.textContent = reduced ? c : ' '; el.appendChild(s);
    if (reduced) return;
    let n = 0;
    const tick = () => {
      n++;
      if (n < 6 + i) { s.classList.add('turn'); setTimeout(() => { s.textContent = CH[Math.floor(Math.random() * CH.length)]; s.classList.remove('turn'); }, 60); setTimeout(tick, 70); }
      else { s.classList.add('turn'); setTimeout(() => { s.textContent = c; s.classList.remove('turn'); }, 60); }
    };
    setTimeout(tick, delay + i * 20);
  });
}

export function Departures({ rows, locale, empty }: { rows: Departure[]; locale: Locale; empty: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const ar = locale === 'ar';
  useEffect(() => {
    const root = ref.current; if (!root) return;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const io = new IntersectionObserver(es => {
      if (!es.some(e => e.isIntersecting)) return; io.disconnect();
      root.querySelectorAll<HTMLElement>('.row').forEach((r, i) => {
        const d = rows[i];
        flap(r.querySelector('.t')!, d.time, i * 120, reduced); flap(r.querySelector('.f')!, d.flight.toUpperCase(), i * 120 + 80, reduced);
        flap(r.querySelector('.g')!, d.gate, i * 120 + 160, reduced); flap(r.querySelector('.s')!, String(d.seats).padStart(2, '0'), i * 120 + 220, reduced);
      });
    }, { threshold: .2 });
    io.observe(root);
    return () => io.disconnect();
  }, [rows]);
  if (!rows.length) return <div className="board"><div className="row" style={{ display: 'block', color: '#AEB9DD' }}>{empty}</div></div>;
  return (
    <div className="board" ref={ref}>
      <div className="bhead"><span>TIME</span><span>LAB · {ar ? 'البرنامج' : 'PROGRAM'}</span><span className="gate">STEM · WHERE</span><span>SEATS</span><span>STATUS</span></div>
      {rows.map((d, i) => {
        const st = d.seats === 0 ? 'full' : d.seats <= 2 ? 'last' : '';
        const txt = d.seats === 0 ? (ar ? 'قائمة انتظار' : 'WAITLIST') : d.seats <= 2 ? (ar ? 'آخر المقاعد' : 'LAST SEATS') : (ar ? 'مفتوح' : 'OPEN');
        return <div className="row" key={i}><span className="flap t">{d.time}</span><span className="flap f">{d.flight.toUpperCase()}</span><span className="flap g gate">{d.gate}</span><span className="flap s">{String(d.seats).padStart(2, '0')}</span><span className={'st ' + st}>{txt}</span></div>;
      })}
    </div>
  );
}
