'use client';
import { useState } from 'react';
import type { Program } from '@/db/schema';
import { DICT, WA, type Locale } from '@/lib/i18n';

export function BookingForm({ locale, programs, preset }: { locale: Locale; programs: Program[]; preset?: string }) {
  const t = DICT[locale];
  const [state, setState] = useState<'idle' | 'sending' | 'ok' | 'err'>('idle');
  const [msg, setMsg] = useState('');
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const body = Object.fromEntries(fd.entries());
    setState('sending');
    try {
      const r = await fetch('/api/bookings', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...body, locale }) });
      const j = await r.json();
      if (r.ok) { setState('ok'); } else { setState('err'); setMsg(j.error || ''); }
    } catch { setState('err'); }
  }
  if (state === "ok") return <div className="ok">{t.book.ok}</div>;
  return (
    <form className="form paper" onSubmit={onSubmit}>
      <div><label htmlFor="parentName">{t.book.name}</label><input id="parentName" name="parentName" required minLength={2} maxLength={80} /></div>
      <div><label htmlFor="phone">{t.book.phone}</label><input id="phone" name="phone" type="tel" inputMode="tel" required placeholder={t.book.phoneHint} pattern="[+0-9 ()-]{9,20}" /></div>
      <div><label htmlFor="childAge">{t.book.age}</label>
        <select id="childAge" name="childAge" defaultValue="8">{Array.from({ length: 15 }, (_, i) => i + 4).map(a => <option key={a} value={a}>{a}</option>)}</select></div>
      <div><label htmlFor="programSlug">{t.book.program}</label>
        <select id="programSlug" name="programSlug" defaultValue={preset || programs[0]?.slug}>
          {programs.map(p => <option key={p.slug} value={p.slug}>{p.name} ({p.ageMin}–{p.ageMax})</option>)}
        </select></div>
      <div><label htmlFor="preferredTime">{t.book.time}</label>
        <select id="preferredTime" name="preferredTime">{t.book.times.map(x => <option key={x} value={x}>{x}</option>)}</select></div>
      <div><label htmlFor="city">{t.book.city}</label><input id="city" name="city" defaultValue={locale === 'ar' ? 'الرياض' : 'Riyadh'} maxLength={60} /></div>
      <div className="full"><label htmlFor="notes">{t.book.notes}</label><textarea id="notes" name="notes" rows={3} maxLength={600} /></div>
      {/* honeypot — bots fill it, people never see it */}
      <input type="text" name="website" tabIndex={-1} autoComplete="off" style={{ position: 'absolute', width: 1, height: 1, opacity: 0, overflow: 'hidden', pointerEvents: 'none' }} aria-hidden="true" />
      <div className="full" style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <button className="btn btn-gold" type="submit" disabled={state === 'sending'}>{state === 'sending' ? t.book.sending : t.book.send}</button>
        <a className="btn btn-wa" href={WA()} target="_blank" rel="noopener">{t.book.wa}</a>
      </div>
      {state === 'err' && <p className="full" style={{ color: '#B71C1C', fontWeight: 700 }}>{t.book.err} {msg}</p>}
      <p className="small full">{t.book.privacy}</p>
    </form>
  );
}
