'use client';
import { useState } from 'react';
import type { Program } from '@/db/schema';
import { DICT, href, type Locale } from '@/lib/i18n';

const Icon = ({ kind }: { kind: string }) => kind === 'skylab'
  ? <svg width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2" fill="currentColor" /><ellipse cx="12" cy="12" rx="10" ry="4.2" fill="none" stroke="currentColor" strokeWidth="1.8" transform="rotate(-25 12 12)" /></svg>
  : kind === 'code'
    ? <svg width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16" /></svg>
    : <svg width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.5-2-3.5-2.4 1a7.7 7.7 0 0 0-1.7-1L15 3.5h-4l-.4 2.5a7.7 7.7 0 0 0-1.7 1l-2.4-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2 1.5 2 3.5 2.4-1a7.7 7.7 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.7 7.7 0 0 0 1.7-1l2.4 1 2-3.5L19.4 13zM13 15a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" /></svg>;

export function AgeRail({ locale, programs, initial = 8 }: { locale: Locale; programs: Program[]; initial?: number }) {
  const t = DICT[locale];
  const [age, setAge] = useState(initial);
  const ar = locale === 'ar';
  const match = programs.filter(p => age >= p.ageMin && age <= p.ageMax);
  return (
    <>
      <div className="rail" role="radiogroup" aria-label={t.rail.h}>
        {Array.from({ length: 15 }, (_, i) => i + 4).map(a => (
          <button key={a} role="radio" aria-checked={age === a} className={'age' + (age === a ? ' on' : '')} onClick={() => setAge(a)}>{a}</button>
        ))}
      </div>
      <div className="match" aria-live="polite">
        {match.map(p => {
          const sky = p.track === 'skylab';
          const kind = sky ? 'skylab' : (p.fieldEn.includes('Coding') ? 'code' : 'gear');
          return (
            <a className="prog" key={p.slug} href={href(locale, sky ? '/skylab' : `/programs/${p.slug}`)}>
              <div className="ico"><Icon kind={kind} /></div>
              <div>
                <span className={'tag' + (sky ? ' sky' : '')}>{sky ? 'SkyLab' : (ar ? p.fieldAr : p.fieldEn)}</span>
                <h4>{p.name}</h4>
                <div className="meta">{t.rail.ages} {p.ageMin}–{p.ageMax} · {p.sessionMin} {t.rail.min} · {t.rail.upto} {p.classCap} · {ar ? p.formatAr : p.formatEn}</div>
                <p className="small" style={{ margin: '6px 0 0' }}>{ar ? p.oneLinerAr : p.oneLinerEn}</p>
              </div>
            </a>
          );
        })}
      </div>
    </>
  );
}
