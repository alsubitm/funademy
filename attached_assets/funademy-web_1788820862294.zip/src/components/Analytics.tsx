'use client';
import { useEffect } from 'react';
/** Privacy-respecting first-party events: page views and clicks on gold / WhatsApp buttons. No third-party pixels. */
export function Analytics({ locale }: { locale: string }) {
  useEffect(() => {
    const send = (name: string, meta: Record<string, unknown> = {}) => {
      try { navigator.sendBeacon('/api/events', new Blob([JSON.stringify({ name, page: location.pathname, locale, meta })], { type: 'application/json' })); } catch {}
    };
    send('page_view');
    const onClick = (e: MouseEvent) => {
      const a = (e.target as HTMLElement).closest('a,button') as HTMLElement | null; if (!a) return;
      const h = (a as HTMLAnchorElement).href || '';
      if (h.includes('wa.me')) send('whatsapp_click');
      else if (a.classList.contains('btn-gold') && h.includes('/book')) send('book_cta_click', { text: a.textContent?.trim() });
    };
    document.addEventListener('click', onClick);
    return () => document.removeEventListener('click', onClick);
  }, [locale]);
  return null;
}
