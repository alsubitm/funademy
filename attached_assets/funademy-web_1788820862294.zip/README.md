# FunAdemy website — funademy.io

Full-stack site for FunAdemy (Falcon Eye Ltd, Riyadh): Arabic-first marketing site with a booking backend and an admin dashboard.

- **Frontend:** Next.js 14 (App Router, TypeScript), server-rendered, Arabic at `/` and English at `/en`, brand design system in `src/app/globals.css`.
- **Backend:** Next.js Route Handlers + PostgreSQL via Drizzle ORM (`src/db/schema.ts`). No third-party form or analytics services.
- **Admin:** `/admin` — bookings pipeline with CSV export, schedule slots (feed the live ticker and the program pages), testimonials approval, FAQ editor, stats.

## Run locally

```bash
cp .env.example .env            # set DATABASE_URL, ADMIN_PASSWORD, AUTH_SECRET
npm install
npm run db:migrate              # applies drizzle/*.sql
npm run db:seed                 # 7 engineering programs + 5 SkyLab altitudes, 14 slots, 6 FAQs, placeholder testimonials (unapproved)
npm run dev                     # http://localhost:3000  ·  /en  ·  /admin
```

Production: `npm run build && npm start` (port 3000). Put it behind HTTPS (nginx/Caddy or the host's proxy).

## Environment

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string — a Saudi-hosted instance in production (PDPL data residency) |
| `ADMIN_PASSWORD` | Password for `/admin` |
| `AUTH_SECRET` | Long random string; signs the admin cookie and hashes IPs |
| `SITE_URL` | Public URL, used in metadata, sitemap and emails |
| `SMTP_HOST/PORT/USER/PASS`, `NOTIFY_EMAIL` | Optional: booking notifications by email (logged to the console when unset) |
| `WHATSAPP_WEBHOOK_URL` | Optional: POSTs each booking as JSON to a WhatsApp Business relay |
| `NEXT_PUBLIC_WHATSAPP` | The WhatsApp number behind every WhatsApp button |

## Data model (PostgreSQL)

`programs` (12 rows: 7 engineering + 5 SkyLab altitudes, bilingual copy, `builds` JSON) · `slots` (weekday, time, seats left — ticker and program pages) · `bookings` (trial requests with status pipeline: new → contacted → trial_booked → enrolled → closed) · `testimonials` (shown only when `approved`) · `faqs` (per page) · `events` (first-party analytics) · `settings` (key/value).

Migrations live in `drizzle/`; change the schema in `src/db/schema.ts`, then `npm run db:generate` and `npm run db:migrate`.

## API

Public
- `GET /api/programs` · `GET /api/slots` · `GET /api/faqs?page=home` · `GET /api/testimonials`
- `POST /api/bookings` — `{ parentName, phone, childAge, programSlug, preferredTime, city, notes, locale }` → `201 { ok, id }`; validated with zod, rate-limited (5 per 10 min per IP), honeypot field `website` must be empty; triggers notifications.
- `POST /api/events` — first-party analytics beacon `{ name, page, locale, programSlug?, meta }`.

Admin (signed HTTP-only cookie; `POST /api/admin/login { password }`, `POST /api/admin/logout`)
- `GET /api/admin/bookings` (`?format=csv` for export) · `PATCH /api/admin/bookings/:id { status, adminNote }`
- `GET/POST /api/admin/slots` · `PATCH/DELETE /api/admin/slots/:id`
- `GET/POST /api/admin/testimonials` · `PATCH/DELETE /api/admin/testimonials/:id`
- `GET/POST /api/admin/faqs` · `PATCH/DELETE /api/admin/faqs/:id`
- `GET /api/admin/stats`

## Deploy

- **Replit (existing project):** import this repository into the existing FunAdemy project, add the env vars in Secrets, attach a PostgreSQL database, run `npm run db:migrate && npm run db:seed`, then `npm run build && npm start`.
- **Any Node host / Docker:** Node 20+, `npm ci && npm run build`, start with `npm start`; point `DATABASE_URL` at the Saudi-hosted PostgreSQL.
- **Fonts:** the layout loads Baloo Bhaijaan 2 and IBM Plex Sans Arabic from Google Fonts; self-host them under `public/fonts` and swap the `<link>` for `@font-face` for full residency.

## Brand and content rules enforced

- "FunAdemy" in Latin script everywhere; the licensed mark appears only in the footer credit line; SkyLab labelled an original FunAdemy program.
- Geography: Riyadh only. Testimonials: approved (real, consented) only.
- No multicolour stripes; the sand stripe is the only divider; gold only on actions and the mark; text never pure black.

## QA before launch

`grep -rniE "شمال الرياض|Riyadh North|North Riyadh|فناديمي" src scripts` must return nothing; run Lighthouse on `/` and `/en`; test `/book` end to end; verify `/admin` login and CSV export; set real `ADMIN_PASSWORD`/`AUTH_SECRET`; approve real testimonials; replace AI placeholder imagery within the first month.
